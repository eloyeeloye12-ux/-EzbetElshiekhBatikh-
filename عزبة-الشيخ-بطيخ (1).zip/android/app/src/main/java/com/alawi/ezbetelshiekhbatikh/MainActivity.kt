package com.alawi.ezbetelshiekhbatikh

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EzbetAppTheme {
                MainAppScreen()
            }
        }
    }
}

// Custom Material 3 Color Theme
private val WatermelonGreen = Color(0xFF2E7D32)
private val WatermelonPink = Color(0xFFE91E63)
private val LightGreenBg = Color(0xFFF1F8E9)
private val LightGrayBg = Color(0xFFFAFAFA)
private val AccentGreen = Color(0xFF4CAF50)

@Composable
fun EzbetAppTheme(content: @Composable () -> Unit) {
    val colorScheme = lightColorScheme(
        primary = WatermelonGreen,
        onPrimary = Color.White,
        secondary = WatermelonPink,
        onSecondary = Color.White,
        background = LightGreenBg,
        surface = Color.White,
        onBackground = Color(0xFF1B5E20),
        onSurface = Color(0xFF263238)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}

// Sealed class for bottom navigation
sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "الرئيسية", Icons.Default.Home)
    object Categories : Screen("categories", "الأقسام", Icons.Default.List)
    object ContactUs : Screen("contact", "اتصل بنا", Icons.Default.Phone)
    object AboutUs : Screen("about", "من نحن", Icons.Default.Info)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                val items = listOf(
                    Screen.Home,
                    Screen.Categories,
                    Screen.ContactUs,
                    Screen.AboutUs
                )
                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title, fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                        selected = currentRoute == screen.route,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = WatermelonGreen,
                            selectedTextColor = WatermelonGreen,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = LightGreenBg
                        ),
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.startDestinationId) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(LightGrayBg)
                .padding(paddingValues)
        ) {
            NavHost(navController = navController, startDestination = Screen.Home.route) {
                composable(Screen.Home.route) { HomeScreen(navController) }
                composable(Screen.Categories.route) { CategoriesScreen() }
                composable(Screen.ContactUs.route) { ContactUsScreen() }
                composable(Screen.AboutUs.route) { AboutUsScreen() }
            }
        }
    }
}

// 1. Home Screen (الرئيسية)
@Composable
fun HomeScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Welcome Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(WatermelonGreen, AccentGreen)
                    ),
                    shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
                )
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "عزبة الشيخ بطيخ",
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "المنصة الرسمية والخدمية الشاملة لأبناء العزبة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.9f),
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Stats Section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard("٣٤ إعلان", "نشط ومتاح الآن", Modifier.weight(1f), WatermelonPink)
            StatCard("٩٢ رقم خدمة", "دليل القرية الشامل", Modifier.weight(1f), WatermelonGreen)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Navigation Grid
        Text(
            text = "الوصول السريع",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp),
            color = Color.DarkGray
        )

        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            QuickLinkRow(
                title1 = "الأقسام والخدمات",
                subtitle1 = "تصفح الدليل وعروض البيع والشراء",
                onClick1 = { navController.navigate(Screen.Categories.route) },
                icon1 = Icons.Default.List,
                color1 = WatermelonGreen,
                title2 = "اتصل بنا فوراً",
                subtitle2 = "دعم مباشر وخطوط ساخنة",
                onClick2 = { navController.navigate(Screen.ContactUs.route) },
                icon2 = Icons.Default.Phone,
                color2 = WatermelonPink
            )

            // News Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "أخر إشعارات وأخبار العزبة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = WatermelonGreen
                        )
                        Box(
                            modifier = Modifier
                                .background(WatermelonPink, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, py = 4.dp)
                        ) {
                            Text(text = "جديد", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "تم بحمدالله تدشين المنصة الإلكترونية لتوفير أرقام الدكاترة والمهن الحرة والصيدليات، مع تسهيل تواصلكم المباشر لحفظ وقتكم ومجهودكم.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun StatCard(number: String, subtitle: String, modifier: Modifier, color: Color) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = number, fontSize = 20.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = subtitle, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun QuickLinkRow(
    title1: String, subtitle1: String, onClick1: () -> Unit, icon1: ImageVector, color1: Color,
    title2: String, subtitle2: String, onClick2: () -> Unit, icon2: ImageVector, color2: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier
                .weight(1f)
                .clickable { onClick1() },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Icon(icon1, contentDescription = title1, tint = color1, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = title1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = subtitle1, fontSize = 10.sp, color = Color.Gray)
            }
        }
        Card(
            modifier = Modifier
                .weight(1f)
                .clickable { onClick2() },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Icon(icon2, contentDescription = title2, tint = color2, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = title2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = subtitle2, fontSize = 10.sp, color = Color.Gray)
            }
        }
    }
}

// 2. Categories Screen (الأقسام)
data class GridCategory(val id: String, val name: String, val icon: ImageVector, val group: String)

@Composable
fun CategoriesScreen() {
    val categories = listOf(
        GridCategory("realestate", "عقارات للبيع والشراء", Icons.Default.Home, "بيع وشراء"),
        GridCategory("cars", "سيارات وموتسيكلات", Icons.Default.Star, "بيع وشراء"),
        GridCategory("mobiles", "موبايلات ولابتوب", Icons.Default.Send, "بيع وشراء"),
        GridCategory("home_apps", "أجهزة منزلية وحديقة", Icons.Default.ShoppingCart, "بيع وشراء"),
        GridCategory("jobs", "الوظائف والمهن الحرة", Icons.Default.Build, "بيع وشراء"),
        
        GridCategory("doctors", "صيدليات وأطباء", Icons.Default.Face, "دليل الخدمات"),
        GridCategory("shops", "محلات تجارية وسوبرماركت", Icons.Default.ShoppingCart, "دليل الخدمات"),
        GridCategory("transit", "مواصلات وسائقين", Icons.Default.AccountBox, "دليل الخدمات"),
        GridCategory("restaurants", "مطاعم مأكولات", Icons.Default.Favorite, "دليل الخدمات"),
        GridCategory("teachers", "مدرسين ومكاتب قرأن", Icons.Default.Edit, "دليل الخدمات"),
        GridCategory("emergency", "طوارئ وبلاغات", Icons.Default.Warning, "دليل الخدمات")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "تصفح أقسام عزبة الشيخ بطيخ",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = WatermelonGreen
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Split to tabs or scroll sections
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(categories) { cat ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clickable { },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    ) {
                        Column(
                            verticalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (cat.group == "بيع وشراء") WatermelonPink.copy(alpha = 0.1f)
                                        else WatermelonGreen.copy(alpha = 0.1f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(6.dp)
                            ) {
                                Icon(
                                    imageVector = cat.icon,
                                    contentDescription = cat.name,
                                    tint = if (cat.group == "بيع وشراء") WatermelonPink else WatermelonGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Text(
                                text = cat.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color.DarkGray
                            )
                        }
                    }
                }
            }
        }
    }
}

// 3. Contact Us Screen (اتصل بنا)
@Composable
fun ContactUsScreen() {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Phone,
            contentDescription = "اتصل بنا",
            tint = WatermelonGreen,
            modifier = Modifier.size(72.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "تواصل مباشر وبلاغات طارئة",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.DarkGray,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "يمكنك التواصل الفوري مع الإدارة أو تصفح الخدمات ومشاركة فكرة جديدة لمساعدة أهل عزبة الشيخ بطيخ.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(30.dp))

        // WhatsApp Action Button
        Button(
            onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/201017437824"))
                context.startActivity(intent)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Share, contentDescription = "واتساب", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "مراسلة عبر واتساب",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Regular Call Button
        Button(
            onClick = {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:01017437824"))
                context.startActivity(intent)
            },
            colors = ButtonDefaults.buttonColors(containerColor = WatermelonGreen),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Phone, contentDescription = "اتصال هاتفي", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "اتصال مباشر (01017437824)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }
    }
}

// 4. About Us Screen (من نحن)
@Composable
fun AboutUsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = "من نحن",
            tint = WatermelonPink,
            modifier = Modifier.size(72.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "تطبيق عزبة الشيخ بطيخ الخدمي",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = WatermelonGreen
        )
        Spacer(modifier = Modifier.height(16.dp))
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "تأسس هذا التطبيق كجهد تطوعي لتقديم خدمات سريعة وسهلة وتغطية لكافة النشاطات التجارية والخيرية والصحية لمواطني وقري قرية الشيخ بطيخ وما حولها.",
                    fontSize = 14.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Start,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "يهدف التطبيق لتمثيل حلقة الوصل لتسهيل حياة المواطنين وتحقيق الاستجابات لحالات الطوارئ مع دمج تكنولوجي يوفر الكفاءة والتواصل المباشر والآمن.",
                    fontSize = 14.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Start,
                    lineHeight = 22.sp
                )
            }
        }
    }
}
