const CACHE_NAME = 'batikh-directory-v94';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=512&h=512&auto=format&fit=crop&fm=png'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
});

self.addEventListener('activate', (event) => {
  self.clients.claim();
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Exclude Firebase, Firestore, and other dynamic APIs
  if (
    url.hostname.includes('googleapis.com') || 
    url.hostname.includes('firebase') ||
    url.hostname.includes('firestore') ||
    url.pathname.startsWith('/api/') || 
    event.request.method !== 'GET'
  ) {
    return;
  }

  // Network First strategy for the main application bundle and index.html
  // and Stale-While-Revalidate for other static assets
  const isCachable = ASSETS_TO_CACHE.some(asset => url.pathname.endsWith(asset)) || 
                     url.pathname === '/' || 
                     url.pathname.includes('.js') || 
                     url.pathname.includes('.css');

  if (isCachable) {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse.ok) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          return caches.match(event.request).then((cachedResponse) => {
            if (cachedResponse) {
              return cachedResponse;
            }
            if (event.request.mode === 'navigate') {
              return caches.match('/');
            }
            return new Response('Offline', { status: 503 });
          });
        })
    );
  }
});

self.addEventListener('push', (event) => {
  let data = { title: 'عزبة بطيخ', body: 'تنبيه جديد من التطبيق!' };
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: '/app_icon.png',
    badge: '/app_icon.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      { action: 'explore', title: 'فتح التطبيق' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      if (clientList.length > 0) {
        let client = clientList[0];
        for (let i = 0; i < clientList.length; i++) {
          if (clientList[i].focused) {
            client = clientList[i];
          }
        }
        return client.focus();
      }
      return clients.openWindow('/');
    })
  );
});
