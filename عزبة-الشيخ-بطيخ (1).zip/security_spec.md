# Security Spec - دليل خدمات عزبة الشيخ بطيخ

## Data Invariants
1. Categories are read-only for public, manageable by admin.
2. Services are read-only for public, manageable by admin.
3. News are read-only for public, manageable by admin.
4. Settings are read-only for public, manageable by admin.
5. All IDs must be valid strings.

## The Dirty Dozen Payloads (Rejection Targets)
1. Attempt to update `settings` without password.
2. Attempt to create a `service` entry via client SDK without being an admin.
3. Attempt to delete a `category` without being an admin.
4. Injecting 1MB string into `service.name`.
5. Spoofing `createdAt` to a future date.
6. Deleting the `settings` document.
7. Creating a `service` with a non-existent `categoryId`.
8. Updating `service.name` with a boolean.
9. Listing `settings` (should only allow `get`).
10. Creating a `news` item with invalid `type`.
11. Bypassing `isValidId` on category IDs.
12. Modifying `service.id` on update.

## Role Logic
- Public: Read only (list/get).
- Admin: Full CRUD on all collections using a verification against `/admins/{uid}` or a secret password check if we were using custom claims, but here we will check if the user exists in an `admins` collection.

*Wait*, the user mentioned a "secret entrance" with a password. In a real Firebase setup, I should ideally use Firebase Auth. But for this specific request, I'll use a `settings` document that stores the `adminPassword`. 

Actually, the best practice is to check an `admins` collection. I'll stick to a simple `isAdmin()` check that checks for a specific document in `/admins/`.
