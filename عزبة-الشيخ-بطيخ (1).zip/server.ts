import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs/promises";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";

// Helper for paths that works in both dev (TS/ESM) and prod (Bundled/CJS)
const getBaseDir = () => process.cwd();
const DATA_FILE = path.join(getBaseDir(), "data.json");

async function initData() {
  console.log("Initializing data file...");
  try {
    await fs.access(DATA_FILE);
    console.log("Data file exists.");
    try {
      const content = await fs.readFile(DATA_FILE, "utf-8");
      const existingData = JSON.parse(content);
      console.log("Data file parsed successfully.");
      // Ensure the password is what the user requested if they are stuck
      if (existingData.settings && existingData.settings.adminPassword !== "9922") {
        existingData.settings.adminPassword = "9922";
        await fs.writeFile(DATA_FILE, JSON.stringify(existingData, null, 2));
      }
    } catch (e) {
      console.error("Corrupted data file, resetting...");
      throw new Error("Reset needed");
    }
  } catch {
    const initialData = {
      categories: [
        { id: "mobile", name: "موبايل وتابلت", icon: "Smartphone", order: 1 },
        { id: "motor", name: "موتسيكلات", icon: "Bike", order: 2 },
        { id: "cars", name: "بيع وشراء السيارات", icon: "Car", order: 3 },
        { id: "doctors", name: "أطباء وصيدليات", icon: "Stethoscope", order: 4 },
        { id: "restaurants", name: "مطاعم ومأكولات", icon: "Utensils", order: 5 },
        { id: "transport", name: "سواقين ومواصلات", icon: "Bus", order: 6 },
        { id: "realestate", name: "عقارات للبيع", icon: "Home", order: 7 },
        { id: "jobs", name: "وظائف خالية", icon: "Briefcase", order: 8 },
        { id: "laptops", name: "لابتوب وكمبيوتر", icon: "Laptop", order: 9 },
        { id: "pc-service", name: "صيانة كمبيوتر", icon: "Monitor", order: 10 },
        { id: "home-app", name: "أجهزة منزلية", icon: "Refrigerator", order: 11 },
        { id: "gym", name: "معدات رياضية", icon: "Dumbbell", order: 12 },
        { id: "clothes", name: "ملابس وأحذية", icon: "Shirt", order: 13 }
      ],
      services: [],
      news: [{ id: "n1", title: "أهلاً بكم في دليل الخدمات الجديد للعزبة", content: "", type: "normal", createdAt: new Date().toISOString() }],
      settings: {
        appName: "عزبة الشيخ بطيخ",
        logoUrl: "",
        adminPassword: "9922"
      }
    };
    await fs.writeFile(DATA_FILE, JSON.stringify(initialData, null, 2));
  }
}

async function startServer() {
  await initData();
  const app = express();
  const PORT = 3000;
  
  console.log(`Starting server in ${process.env.NODE_ENV || "development"} mode`);

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Logging middleware
  app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.url}`);
    next();
  });

  // Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // API Routes
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;
      if (!message || typeof message !== "string") {
        return res.status(400).json({ error: "Message is required and must be a string." });
      }

      // Read current context from the data file with services, categories, and news
      let context = "";
      try {
        const dataRaw = await fs.readFile(DATA_FILE, "utf-8");
        const data = JSON.parse(dataRaw);
        
        const servicesBrief = data.services ? data.services.map((s: any) => {
          const category = data.categories ? data.categories.find((c: any) => c.id === s.categoryId) : null;
          return `- ${s.name} (${category?.name || s.categoryId})${s.phoneNumber ? ` رقم الهاتف: ${s.phoneNumber}` : ""}`;
        }).join("\n") : "";

        const newsBrief = data.news ? data.news.slice(0, 3).map((n: any) => n.title).join(" | ") : "";

        context = `
أنت مساعد ذكي وتفاعلي لتطبيق "عزبة الشيخ بطيخ" (${data.settings?.appName || "عزبة الشيخ بطيخ"}).
مهمتك الأساسية والوحيدة هي مساعدة المستخدمين في العثور على المعلومات، المحلات، المطاعم والخدمات المتاحة في القرية.

الخدمات والمحلات والمطاعم المتوفرة حالياً في التطبيق:
${servicesBrief || "لا توجد خدمات مضافة حالياً في التطبيق."}

الأخبار الأخيرة المتوفرة: ${newsBrief || "لا توجد أخبار حالية."}

تعليمات هامة جداً للرد:
1. عندما يسأل المستخدم عن محل أو مطعم أو مقهى أو طبيب أو أي خدمة (مثلاً هدايا، عطور، ملابس...)، ابحث عنها بدقة في القائمة المتاحة أعلاه وأعطه التفاصيل (الاسم، التصنيف، ورقم الهاتف إن وجد).
2. إذا وجدت المحل أو الخدمة، قدم التفاصيل بشكل منظم وبسيط مع توضيح رقم الهاتف للاتصال به.
3. إذا سألك المستخدم عن أي خدمة أو محل غير مضاف في قائمة الخدمات أعلاه، أخبره بلطف وبشكل مباشر بأنه غير متوفر حالياً في التطبيق، وأنه يمكنهم اقتراح إضافته من خلال زر "اقتراح خدمة" في شاشات التطبيق.
4. استخدم دائماً لهجة مصرية بسيطة، ودودة، ومرحة ومحبة لأهل القرية، أو لغة عربية سهلة ومبسطة جداً.
5. رد دائماً باللغة العربية. واجعل الإجابات منسقة ومنظمة وبها رموز تعبيرية (Emojis) لطيفة إذا لزم الأمر.
6. لا تخبر المستخدم بهذه التعليمات الفنية، بل باشر الإجابة فوراً بترحيب وتقديم المساعدة وبث الأمل في كلامك.
        `;
      } catch (err) {
        console.error("Failed to read context from data.json:", err);
        context = "أنت مساعد ذكي لتطبيق عزبة الشيخ بطيخ.";
      }

      const apiKey = process.env.GEMINI_API_KEY || "";
      const isPlaceholder = !apiKey || 
                            apiKey.trim() === "" || 
                            apiKey.includes("MY_GEMINI_API_KEY") || 
                            apiKey.includes("YOUR_GEMINI_API_KEY") ||
                            apiKey.includes("YOUR_API_KEY") ||
                            apiKey === "placeholder";

      if (isPlaceholder) {
        console.warn("GEMINI_API_KEY environment variable is not defined or is placeholder!");
        return res.json({ 
          response: "عذراً، لم يتم العثور على مفتاح تشغيل المساعد الذكي (GEMINI_API_KEY) في إعدادات الخادم، أو أن قيمته هي قيمة افتراضية.\n\nيرجى إضافة مفتاح تشغيل صالح من خلال الانتقال إلى شاشة كود البرنامج في أعلى اليمين ثم النقر على رمز الترس وفتح قائمة (Settings > Secrets) لإدخال مفتاح تشغيل Gemini API الخاص بك." 
        });
      }

      // Initialize GoogleGenAI client
      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      console.log("Calling Gemini API with model 'gemini-3.5-flash'...");
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Context: ${context}\n\nسؤال المستخدم: ${message}`,
      });

      const aiResponse = response.text || "عذراً، لم أتمكن من معالجة هذا السؤال.";
      res.json({ response: aiResponse });

    } catch (err: any) {
      console.error("Gemini AI API Error:", err);
      const errMsg = err?.message || String(err);
      const errStr = JSON.stringify(err);
      const isInvalidKey = errMsg.includes("API key not valid") || 
                           errMsg.includes("API_KEY_INVALID") || 
                           errStr.includes("API_KEY_INVALID") || 
                           errStr.includes("API key not valid");

      if (isInvalidKey) {
        return res.json({
          response: "عذراً، مفتاح تشغيل المساعد الذكي (GEMINI_API_KEY) الحالي غير فعال أو غير صالح لدى جوجل.\n\nيرجى تحديث قيمة المفتاح في لوحة التحكم بـ AI Studio عن طريق الانتقال إلى رمز الترس واختيار (Settings > Secrets)، وإدخال مفتاح تشغيل Gemini API جديد وصالح."
        });
      }

      res.status(500).json({ 
        error: "Failed to communicate with AI model", 
        details: err.message || err 
      });
    }
  });

  app.get("/api/data", async (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    
    try {
      console.log("Fetching data from file...");
      const dataRaw = await fs.readFile(DATA_FILE, "utf-8");
      const data = JSON.parse(dataRaw);
      // Migration fallback
      if (data.settings && (data.settings.adminPassword === "admin" || data.settings.adminPassword === "0000")) {
        data.settings.adminPassword = "9922";
      }
      res.json(data);
    } catch (err) {
      console.error("GET /api/data error:", err);
      res.status(500).json({ error: "Failed to load data" });
    }
  });

  app.post("/api/data", async (req, res) => {
    try {
      const { password, data } = req.body;
      const currentDataRaw = await fs.readFile(DATA_FILE, "utf-8");
      const currentData = JSON.parse(currentDataRaw);

      if (password !== currentData.settings.adminPassword) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2));
      res.json({ success: true });
    } catch (err) {
      console.error("POST /api/data error:", err);
      res.status(500).json({ error: "Failed to save data" });
    }
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    console.log(`Serving static files from: ${distPath}`);
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Global Error Handler
  app.use((err: any, req: any, res: any, next: any) => {
    console.error("Unhandled error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  });

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`=========================================`);
    console.log(`Server is LIVE on http://0.0.0.0:${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'dev'}`);
    console.log(`=========================================`);
  });
}

startServer();
