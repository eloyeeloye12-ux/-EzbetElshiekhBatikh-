/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { VillageData } from "./types";
import VillageView from "./components/VillageView";
import AdminPanel from "./components/AdminPanel";
import Login from "./components/Login";
import PrivacyPolicy from "./components/PrivacyPolicy";
import { X, Download, WifiOff } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { subscribeToVillageData, addEntity, deleteEntity, updateEntity, updateSettings, testConnection, requestNotificationPermission } from "./services/firebaseService";
import { DEFAULT_CATEGORIES } from "./utils/defaultCategories";

export default function App() {
  const [data, setData] = useState<VillageData | null>(null);
  const [view, setView] = useState<"home" | "admin" | "login" | "privacy">(
    window.location.search.includes("p=privacy") ? "privacy" : "home"
  );
  const [loading, setLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [isInAppBrowser, setIsInAppBrowser] = useState(false);
  const [syncStatus, setSyncStatus] = useState<"syncing" | "synced" | "error">("syncing");

  useEffect(() => {
    // Check if we are on iOS
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIOSDevice);

    // Detect In-App Browsers (Facebook, Instagram, etc)
    const isInApp = /fbav|fbios|fban|fb_iab|instagram|twitter|linkedin/.test(userAgent);
    setIsInAppBrowser(isInApp);

    // Check if already in standalone mode
    const isStandaloneMode = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
    setIsStandalone(isStandaloneMode);

    // Check if prompt was already captured in index.html
    if ((window as any).deferredPrompt) {
      setDeferredPrompt((window as any).deferredPrompt);
    }
  }, []);

  useEffect(() => {
    // Restore synchronization logic
    console.log("Setting up real-time Firebase subscription...");
    setSyncStatus("syncing");
    
    // Track if we have any server-confirmed data
    const unsubscribe = subscribeToVillageData((newData, metadata) => {
      console.log("Real-time update received. Metadata:", metadata);
      
      // Auto-correct old numbers, developer name, and admin password if found in DB settings
      if (newData && newData.settings && newData.settings.firebase_loaded) {
        let needsUpdate = false;
        const updatedSettings = { ...newData.settings };
        
        if (updatedSettings.splashPhone === "01097854099") {
          updatedSettings.splashPhone = "";
          needsUpdate = true;
        }
        if (!updatedSettings.developerName || updatedSettings.developerName === "ali sayed") {
          updatedSettings.developerName = "علوي عبدالرزاق";
          needsUpdate = true;
        }
        if (updatedSettings.adminPassword !== "9922") {
          updatedSettings.adminPassword = "9922";
          needsUpdate = true;
        }
        if (!updatedSettings.apkDownloadUrl || updatedSettings.apkDownloadUrl !== "https://drive.google.com/file/d/1bfSFw282UojTFoAETSsnL-sQTO8KW997/view?usp=drivesdk") {
          updatedSettings.apkDownloadUrl = "https://drive.google.com/file/d/1bfSFw282UojTFoAETSsnL-sQTO8KW997/view?usp=drivesdk";
          needsUpdate = true;
        }
        if (updatedSettings.hideLogoOverlay !== true) {
          updatedSettings.hideLogoOverlay = true;
          needsUpdate = true;
        }
        if (!updatedSettings.appName || updatedSettings.appName === "My App" || updatedSettings.appName === "عزبة الشيخ بطيخ App" || updatedSettings.appName === "عزبة الشيخ بطيخ" || updatedSettings.appName === "سوق دار السلام") {
          updatedSettings.appName = "دليل عزبة الشيخ بطيخ";
          needsUpdate = true;
        }
        if (!updatedSettings.welcomeMessage || updatedSettings.welcomeMessage === "مرحبا بكم في سوق دار السلام") {
          updatedSettings.welcomeMessage = "مرحبا بكم في دليل عزبة الشيخ بطيخ";
          needsUpdate = true;
        }
        if (!updatedSettings.splashTitle || updatedSettings.splashTitle === "عزبة الشيخ بطيخ" || updatedSettings.splashTitle === "سوق دار السلام") {
          updatedSettings.splashTitle = "دليل عزبة الشيخ بطيخ";
          needsUpdate = true;
        }
        if (!updatedSettings.splashSubtitle || updatedSettings.splashSubtitle === "دليل الخدمات الشامل" || updatedSettings.splashSubtitle === "كل اللي تحتاجه في دار السلام.. أسرع وأسهل") {
          updatedSettings.splashSubtitle = "كل اللي تحتاجه في عزبة الشيخ بطيخ.. أسرع وأسهل";
          needsUpdate = true;
        }
        
        if (needsUpdate) {
          console.log("Auto-correcting settings in Firestore...");
          updateSettings(updatedSettings).then(() => {
            console.log("Firestore settings auto-corrected successfully.");
          });
          // Update local state copy so changes are immediate
          newData.settings = updatedSettings;
        }
      }

      // Auto-populate missing categories so the admin can manage them inside the database
      if (newData && newData.categories) {
        const missingCategories = DEFAULT_CATEGORIES.filter(
          (defaultCat) => !newData.categories.some((dbCat) => dbCat.id === defaultCat.id)
        );
        if (missingCategories.length > 0) {
          console.log(`Auto-seeding ${missingCategories.length} missing categories to Firestore...`);
          Promise.all(
            missingCategories.map((cat) =>
              addEntity("categories", cat.id, {
                id: cat.id,
                name: cat.name,
                icon: cat.icon,
                order: cat.order,
                image: "",
                group: cat.group,
              })
            )
          ).then(() => {
            console.log("Seeding of categories completed.");
          }).catch(err => {
            console.error("Failed to seed some categories:", err);
          });
        }
      }

      setData(newData);
      setLoading(false);
      
      if (metadata.isFromCache) {
        // If we have data from cache but are online, we are still "syncing"
        setSyncStatus(navigator.onLine ? "syncing" : "synced");
      } else {
        setSyncStatus("synced");
      }
    }, (err) => {
      console.error("Subscription error:", err);
      // Only set error if we don't have any data yet
      if (!data) {
        setSyncStatus("error");
        setLoading(false);
      }
    });

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    // Add a timeout fallback for initial loading screen only if no data at all
    const loadTimeout = setTimeout(() => {
      if (loading && !data) {
        console.warn("Initial data load timed out. Using cache fallback if available.");
        setSyncStatus("error"); // This triggers the "Working Offline" banner which is okay if NO data.
        // But if we have cache, it will have already called setData and setLoading(false)
      }
    }, 5000);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      unsubscribe();
      clearTimeout(loadTimeout);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    // Icons updating logic
    if (data?.settings?.homeIconUrl) {
      const updateIcon = (rel: string, href: string) => {
        let link = document.querySelector(`link[rel*='${rel}']`) as HTMLLinkElement;
        if (!link) {
          link = document.createElement('link');
          link.rel = rel;
          document.head.appendChild(link);
        }
        link.href = `${href}?v=${Date.now()}`;
      };
      updateIcon('icon', data.settings.homeIconUrl);
      updateIcon('apple-touch-icon', data.settings.homeIconUrl);
      updateIcon('shortcut icon', data.settings.homeIconUrl);
    }
  }, [data?.settings?.homeIconUrl]);

  useEffect(() => {
    // 1. Capture the signal immediately
    const handlePWAInstallable = () => {
      const prompt = (window as any).deferredPrompt;
      if (prompt) {
        setDeferredPrompt(prompt);
      }
    };

    const handleInstalled = () => {
      console.log('PWA: Successfully Installed');
      setDeferredPrompt(null);
      (window as any).deferredPrompt = null;
    };

    // Initialize if already present in global scope
    if ((window as any).deferredPrompt) {
      setDeferredPrompt((window as any).deferredPrompt);
    }

    window.addEventListener('pwa-installable', handlePWAInstallable);
    window.addEventListener('pwa-installed', handleInstalled);
    window.addEventListener('appinstalled', handleInstalled);
    
    // Request notification permission on load
    const initNotifications = async () => {
      await requestNotificationPermission();
    };
    initNotifications();
    
    return () => {
      window.removeEventListener('pwa-installable', handlePWAInstallable);
      window.removeEventListener('pwa-installed', handleInstalled);
      window.removeEventListener('appinstalled', handleInstalled);
    };
  }, []);

  const triggerInstall = async () => {
    if ((window as any).triggerNativeInstall) {
      const prompt = (window as any).deferredPrompt;
      if (!prompt && !isIOS) {
         // Show a temporary message if it's not ready
         alert("المتصفح يجهز ميزة التثبيت، انتظر ثواني وحاول مرة أخرى");
      }
      (window as any).triggerNativeInstall();
    }
  };

  const handleAdminAction = async (action: 'add' | 'delete' | 'update', collectionName: string, id: string, payload?: any) => {
    if (action === 'add') {
      return await addEntity(collectionName, id, payload);
    } else if (action === 'delete') {
      return await deleteEntity(collectionName, id);
    } else if (action === 'update') {
      if (collectionName === 'settings') {
        return await updateSettings(payload);
      } else {
        return await updateEntity(collectionName, id, payload);
      }
    }
    return false;
  };

  const [showIntro, setShowIntro] = useState(false);
  const [introAnimationComplete, setIntroAnimationComplete] = useState(true);

  useEffect(() => {
    // Removed the artificial 3.2 seconds delay so the app opens instantly
    setIntroAnimationComplete(true);
  }, []);

  const splashActive = loading && !data;

  useEffect(() => {
    if (!loading && data) {
      setShowIntro(false);
    }
  }, [loading, data]);

  const splashTitle = data?.settings?.splashTitle || "دليل عزبة الشيخ بطيخ";
  const words = splashTitle.split(" ");

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.45,
      }
    }
  };

  const wordVariants = {
    hidden: { 
      opacity: 0, 
      y: 35, 
      scale: 0.8,
      filter: "blur(6px)"
    },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      filter: "blur(0px)",
      transition: {
        type: "spring",
        stiffness: 90,
        damping: 12,
      }
    }
  };

  // If data is empty (first time use), provide a default structure or wait
  const effectiveData = data || { categories: [], services: [], news: [], settings: { appName: "دليل عزبة بطيخ", logoUrl: "" } };

  return (
    <div className="min-h-screen bg-gray-50 font-sans" dir="rtl">
      <AnimatePresence mode="wait">
        {splashActive && (
          <motion.div
            key="splash"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(8px)" }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
            className="fixed inset-0 z-[300] flex flex-col items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 overflow-hidden select-none"
          >
            {/* Background glowing effects */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <motion.div 
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [0.12, 0.22, 0.12]
                }}
                transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-40 -left-10 w-[500px] h-[500px] rounded-full bg-blue-600/15 blur-[120px]" 
              />
              <motion.div 
                animate={{ 
                  scale: [1.2, 1, 1.2],
                  opacity: [0.1, 0.18, 0.1]
                }}
                transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 2 }}
                className="absolute -bottom-45 -right-10 w-[500px] h-[500px] rounded-full bg-indigo-500/15 blur-[120px]" 
              />
            </div>

            {/* Decorative Central Circular Emblem */}
            <motion.div
              initial={{ scale: 0.3, opacity: 0, rotate: -30 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              transition={{ duration: 1.2, type: "spring", bounce: 0.25 }}
              className="relative w-40 h-40 md:w-48 md:h-48 rounded-full bg-white/5 backdrop-blur-xl flex items-center justify-center p-1.5 border border-white/20 shadow-[0_24px_60px_rgba(0,0,0,0.6)] mb-8 overflow-hidden"
            >
              <div className="absolute inset-0 rounded-full overflow-hidden pointer-events-none z-10">
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent -translate-x-full"
                  animate={{ translateX: ["100%", "-100%"] }}
                  transition={{ repeat: Infinity, duration: 3.5, ease: "linear" }}
                />
              </div>
              <img 
                src={effectiveData?.settings?.logoUrl || "/app_icon.png"} 
                className="w-full h-full rounded-full object-cover shadow-inner hover:scale-105 transition-transform duration-500 drop-shadow-[0_8px_24px_rgba(59,130,246,0.3)]" 
                alt="دليل عزبة الشيخ بطيخ Emblem"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = "https://cdn-icons-png.flaticon.com/512/3211/3213567.png";
                }}
              />
            </motion.div>

            {/* Animated Word by Word Typography */}
            <motion.div 
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="flex items-center gap-x-4 gap-y-2 justify-center flex-wrap px-6 text-center max-w-xl mb-4 font-sans font-black"
            >
              {words.map((word, index) => (
                <motion.span
                  key={index}
                  variants={wordVariants}
                  className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-blue-50 to-blue-200 drop-shadow-[0_4px_16px_rgba(30,58,138,0.4)] tracking-wide"
                >
                  {word}
                </motion.span>
              ))}
            </motion.div>

            {/* Subtitle Transition */}
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.6, duration: 0.8 }}
              className="text-sm md:text-base font-extrabold text-blue-300/60 font-sans tracking-widest"
            >
              {data?.settings?.splashSubtitle || "دليل الخدمات الشامل"}
            </motion.p>
            
            {/* Loading Indicator */}
            <div className="absolute bottom-16 left-0 right-0 flex flex-col items-center gap-3">
              {loading ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.8 }}
                  className="flex flex-col items-center gap-2"
                >
                  <div className="w-6 h-6 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
                  <span className="text-xs text-blue-400/60 font-bold font-sans">جاري تحميل البيانات...</span>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 2.2, type: "spring" }}
                  onClick={() => setShowIntro(false)}
                  className="px-6 py-2 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 cursor-pointer active:scale-95 transition-all flex items-center gap-2"
                >
                  <span className="text-xs text-blue-100 font-extrabold font-sans">دخول التطبيق</span>
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {syncStatus === "error" && !data && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-[201] w-[90%] max-w-md bg-orange-600 text-white p-6 rounded-3xl flex flex-col items-center gap-4 shadow-2xl border-4 border-white/20 text-center"
          >
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center animate-pulse">
               <WifiOff className="w-8 h-8" />
            </div>
            <div>
               <h3 className="text-lg font-black mb-1">خطأ في الاتصال بالبيانات</h3>
               <p className="text-sm font-bold opacity-90">يبدو أن هناك مشكلة في جلب البيانات الجديدة. تأكد من اتصالك بالإنترنت.</p>
            </div>
            <div className="flex gap-4 w-full">
               <button 
                onClick={() => window.location.reload()}
                className="flex-1 bg-white text-orange-600 py-3 rounded-2xl font-black text-sm active:scale-95 transition-all"
               >
                إعادة المحاولة
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {!isOnline && (
          <motion.div 
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -50, opacity: 0 }}
            className="fixed top-0 left-0 right-0 z-[200] bg-red-600 text-white p-3 flex items-center justify-center gap-3 font-black shadow-xl"
          >
            <WifiOff className="w-5 h-5 animate-pulse" />
            <span>لا يوجد اتصال بالإنترنت .. جاري المحاولة</span>
            <button 
              onClick={() => window.location.reload()}
              className="bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg text-xs font-bold transition-all border border-white/20"
            >
              تحديث الصفحة
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {view === "home" && (
        <VillageView 
          data={effectiveData} 
          onAdminClick={() => setView("login")} 
          triggerInstall={triggerInstall}
          isStandalone={isStandalone}
          deferredPrompt={deferredPrompt}
          isIOS={isIOS}
          isInAppBrowser={isInAppBrowser}
        />
      )}
      {view === "privacy" && (
        <PrivacyPolicy 
          onBack={() => {
            setView("home");
            window.history.pushState({}, "", window.location.pathname);
          }}
          appName={effectiveData.settings.appName || "دليل عزبة الشيخ بطيخ"}
          developerName={effectiveData.settings.developerName || "علوي عبدالرزاق"}
        />
      )}
      {view === "login" && (
        <Login 
          onSuccess={() => setView("admin")} 
          onBack={() => setView("home")}
          adminPassword={effectiveData.settings.adminPassword === "admin" ? "9922" : (effectiveData.settings.adminPassword || "9922")}
        />
      )}
      {view === "admin" && (
        <AdminPanel 
          data={effectiveData} 
          onAdminAction={handleAdminAction}
          onBack={() => setView("home")}
        />
      )}
    </div>
  );
}

