import { useState, useRef, useEffect } from "react";
import { MessageSquare, Send, X, Bot, User, Loader2, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { VillageData } from "../types";

interface AIChatProps {
  isOpen: boolean;
  onClose: () => void;
  villageData: VillageData;
}

interface Message {
  role: "user" | "model";
  text: string;
}

export default function AIChat({ isOpen, onClose, villageData }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    { role: "model", text: "أهلاً بك! أنا مساعدك الذكي في عزبة الشيخ بطيخ. كيف يمكنني مساعدتك اليوم؟" }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", text: userMessage }]);
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: userMessage })
      });

      if (!response.ok) {
        throw new Error("Failed to communicate with the server");
      }

      const data = await response.json();
      const aiResponse = data.response || "عذراً، حدث خطأ في معالجة طلبك.";
      setMessages(prev => [...prev, { role: "model", text: aiResponse }]);
    } catch (error) {
      console.error("AI Chat Error:", error);
      setMessages(prev => [...prev, { role: "model", text: "عذراً، لم أتمكن من الاتصال بالذكاء الاصطناعي حالياً. يرجى المحاولة لاحقاً." }]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[500] bg-blue-900/40 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={onClose}
    >
      <motion.div 
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        className="bg-white w-full max-w-md h-[80vh] sm:h-[600px] rounded-t-[40px] sm:rounded-[40px] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 bg-[#002d72] text-white flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-blue-500 rounded-2xl flex items-center justify-center shadow-lg animate-pulse">
                <Bot className="w-6 h-6 text-white" />
             </div>
             <div>
                <h3 className="font-black text-lg leading-none">المساعد الذكي</h3>
                <span className="text-[10px] text-blue-300 font-bold uppercase tracking-widest">مدعوم بـ AI</span>
             </div>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Messages */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50/50"
        >
          {messages.map((msg, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
              animate={{ opacity: 1, x: 0 }}
              className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
            >
              <div className={`max-w-[85%] p-4 rounded-3xl shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-br-none' 
                  : 'bg-white text-gray-800 rounded-bl-none border border-gray-100'
              }`}>
                 <div className="flex items-center gap-2 mb-1 opacity-70">
                    {msg.role === 'user' ? <User className="w-3 h-3" /> : <Bot className="w-3 h-3" />}
                    <span className="text-[10px] font-black uppercase tracking-widest">
                       {msg.role === 'user' ? 'أنت' : 'مساعد بطيخ'}
                    </span>
                 </div>
                 <p className="text-sm font-bold leading-relaxed">{msg.text}</p>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <div className="flex justify-end">
               <div className="bg-white p-4 rounded-3xl rounded-bl-none shadow-sm flex items-center gap-3 border border-gray-100">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  <span className="text-xs font-bold text-gray-400">جاري التفكير...</span>
               </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-4 bg-white border-t border-gray-100">
          <div className="relative flex items-center gap-2">
            <input 
              type="text"
              className="flex-1 bg-gray-50 border-2 border-transparent py-4 pr-6 pl-14 rounded-2xl outline-none font-bold text-blue-900 focus:border-blue-600 focus:bg-white transition-all shadow-inner"
              placeholder="اسألني أي شيء..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <button 
              onClick={handleSend}
              disabled={isLoading || !input.trim()}
              className="absolute left-2 w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-blue-100 active:scale-95 transition-all disabled:opacity-50"
            >
              <Send className="w-5 h-5 -rotate-45" />
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
