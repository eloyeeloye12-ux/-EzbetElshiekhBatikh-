import React, { useState, useRef, useEffect } from "react";
import { VillageData, Category, ServiceEntry, News } from "../types";
import { Plus, Save, Trash2, Edit2, X, ChevronRight, Settings, Users, Grid, Bell, LogOut, Image, Phone, MapPin, Type, Shield, Upload, CheckCircle, Smartphone, Lock, Download } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import * as LucideIcons from "lucide-react";

interface AdminPanelProps {
  data: VillageData;
  onAdminAction: (action: 'add' | 'delete' | 'update', collection: string, id: string, payload?: any) => Promise<boolean>;
  onBack: () => void;
}

const DynamicIcon = ({ name, className }: { name: string; className?: string }) => {
  const IconComponent = (LucideIcons as any)[name] || LucideIcons.HelpCircle;
  return <IconComponent className={className} />;
};

export default function AdminPanel({ data, onAdminAction, onBack }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<"services" | "categories" | "news" | "settings" | "feedback" | "pending" >("services");
  const [isSaving, setIsSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [commentToConvert, setCommentToConvert] = useState<any | null>(null);

  // File upload refs
  const photoInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const categoryImageInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const splashInputRef = useRef<HTMLInputElement>(null);

  // Manager identification
  const [managerName, setManagerName] = useState(() => localStorage.getItem("manager_name") || "");
  const [showManagerPrompt, setShowManagerPrompt] = useState(!localStorage.getItem("manager_name"));

  // local settings state for explicit save
  const [tempSettings, setTempSettings] = useState(data.settings);

  useEffect(() => {
    setTempSettings(data.settings);
  }, [data.settings]);

  // Form States
  const [newService, setNewService] = useState<Partial<ServiceEntry>>({ 
    id: "", name: "", phoneNumber: "", categoryId: "", description: "", address: "", photoUrl: "", gallery: [] 
  });
  const [newCategory, setNewCategory] = useState<Partial<Category>>({ id: "", name: "", icon: "Store", image: "", order: 0 });
  const [newNews, setNewNews] = useState<Partial<News>>({ id: "", title: "", content: "", type: "normal" });

  const showStatus = (msg: string) => {
    setSaveStatus(msg);
    setTimeout(() => setSaveStatus(null), 3000);
  };

  const compressImage = (base64Str: string, maxWidth = 800, maxHeight = 800, quality = 0.7): Promise<string> => {
    return new Promise((resolve) => {
      const img = new window.Image();
      img.src = base64Str;
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL("image/jpeg", quality));
        } else {
          resolve(base64Str);
        }
      };
      img.onerror = () => {
        resolve(base64Str);
      };
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'photo' | 'gallery' | 'category' | 'logo' | 'splash') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      
      // Compress the image before setting the state
      compressImage(base64String).then((compressedBase64) => {
        if (target === 'photo') {
          setNewService(prev => ({ ...prev, photoUrl: compressedBase64 }));
        } else if (target === 'gallery') {
          setNewService(prev => ({ ...prev, gallery: [...(prev.gallery || []), compressedBase64] }));
        } else if (target === 'category') {
          setNewCategory(prev => ({ ...prev, image: compressedBase64 }));
        } else if (target === 'logo') {
          setTempSettings(prev => ({ ...prev, logoUrl: compressedBase64 }));
        } else if (target === 'splash') {
          setTempSettings(prev => ({ ...prev, splashIconUrl: compressedBase64 }));
        }
        showStatus("تم رفع الصورة وضغطها بنجاح");
      });
      
      if (e.target) e.target.value = ""; // Reset input
    };
    reader.readAsDataURL(file);
  };

  const addService = async () => {
    if (!newService.name) return showStatus("يرجى كتابة الاسم");
    if (!newService.categoryId) return showStatus("يرجى اختيار القسم");
    if (!newService.phoneNumber) return showStatus("يرجى كتابة رقم الهاتف");
    
    setIsSaving(true);
    const id = editingId || (Date.now().toString(36) + Math.random().toString(36).substr(2, 5));
    const payload = {
      ...newService,
      id,
      addedBy: managerName || "مدير التطبيق",
      updatedAt: new Date().toISOString(),
      createdAt: newService.createdAt || new Date().toISOString()
    };
    const success = await onAdminAction(editingId ? 'update' : 'add', 'services', id, payload);
    setIsSaving(false);
    if (success) {
      setNewService({ id: "", name: "", phoneNumber: "", categoryId: "", description: "", photoUrl: "", gallery: [] });
      setEditingId(null);
      showStatus(editingId ? "تم التعديل بنجاح" : "تم حفظ الخدمة بنجاح");
    }
  };

  const startEditService = (service: ServiceEntry) => {
    setNewService(service);
    setEditingId(service.id);
    setActiveTab("services");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const deleteService = async (id: string) => {
    if (confirm("هل أنت متأكد من الحذف؟")) {
      await onAdminAction('delete', 'services', id);
      showStatus("تم الحذف");
    }
  };

  const addCategory = async () => {
    if (!newCategory.name) return showStatus("يرجى كتابة اسم القسم");
    if (!newCategory.icon) return showStatus("يرجى اختيار أيقونة");
    
    setIsSaving(true);
    const id = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    const payload = { ...newCategory, id, order: data.categories.length + 1 };
    const success = await onAdminAction('add', 'categories', id, payload);
    setIsSaving(false);
    if (success) {
      setNewCategory({ id: "", name: "", icon: "Store", image: "", order: 0 });
      showStatus("تم إضافة القسم");
    }
  };

  const addNews = async () => {
    if (!newNews.title) return showStatus("يرجى كتابة عنوان الخبر");
    if (!newNews.content) return showStatus("يرجى كتابة تفاصيل الخبر");
    
    setIsSaving(true);
    const id = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    const payload = { 
      ...newNews, 
      id, 
      addedBy: managerName || "مدير التطبيق",
      createdAt: new Date().toISOString() 
    };
    const success = await onAdminAction('add', 'news', id, payload);
    setIsSaving(false);
    if (success) {
      setNewNews({ id: "", title: "", content: "", type: "normal" });
      showStatus("تم نشر الخبر بنجاح");
    }
  };

  const [showQuickAddCategory, setShowQuickAddCategory] = useState(false);

  if (showManagerPrompt) {
    return (
      <div className="fixed inset-0 z-[200] bg-white flex items-center justify-center p-6 text-right" dir="rtl">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-full max-w-sm space-y-8">
          <div className="text-center">
            <div className="w-20 h-20 bg-blue-600 rounded-3xl mx-auto flex items-center justify-center text-white mb-6 shadow-xl">
              <Users className="w-10 h-10" />
            </div>
            <h2 className="text-2xl font-black text-blue-900 mb-2">من الذي يعمل الآن؟</h2>
            <p className="text-gray-400 font-bold text-sm">حدد اسمك ليتم تسجيل العمل باسمك في سجل الإدارة.</p>
          </div>
          <div className="space-y-4">
            <input 
               autoFocus
               className="w-full px-6 py-5 rounded-2xl bg-gray-100 border-2 border-gray-100 font-bold outline-none focus:border-blue-500 focus:bg-white transition-all shadow-sm"
               placeholder="اكتب اسمك هنا..."
               value={managerName}
               onChange={e => setManagerName(e.target.value)}
            />
            <button 
              onClick={() => {
                if (managerName.trim()) {
                  localStorage.setItem("manager_name", managerName.trim());
                  setShowManagerPrompt(false);
                }
              }}
              className="w-full py-5 bg-blue-600 text-white rounded-2xl font-black shadow-xl hover:bg-blue-700 transition-all active:scale-95"
            >
              دخول للوحة التحكم
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen text-right" dir="rtl">
      {/* Admin Header */}
      <div className="bg-gray-900 text-white p-6 sticky top-0 z-50 shadow-xl">
        <div className="flex items-center justify-between gap-4 max-w-6xl mx-auto">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-orange-600 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-900/20">
              <Shield className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">لوحة الإدارة</h1>
              <p className="text-xs text-gray-400 font-bold mt-0.5">التحكم الكامل في محتوى الدليل</p>
            </div>
          </div>
          <button 
            onClick={onBack}
            className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 px-5 py-3 rounded-2xl transition-all font-bold text-sm"
          >
            <LogOut className="w-5 h-5 text-red-400" />
            إغلاق اللوحة
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto flex flex-col md:flex-row min-h-[calc(100vh-100px)]">
        {/* Navigation Sidebar */}
        <div className="w-full md:w-72 bg-gray-50 border-l border-gray-100 p-6 space-y-3">
          {[
            { id: "services", icon: Users, label: "دليل الخدمات" },
            { id: "pending", icon: CheckCircle, label: "طلبات الموافقة", badge: data.services.filter(s => s.approved === false).length },
            { id: "categories", icon: Grid, label: "الأقسام والرموز" },
            { id: "news", icon: Bell, label: "أخبار القرية" },
            { id: "notifications", icon: Smartphone, label: "الإشعارات (FCM)" },
            { id: "feedback", icon: LucideIcons.MessageSquare, label: "رسائل العملاء" },
            { id: "settings", icon: Shield, label: "إعدادات التطبيق" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center justify-between px-6 py-4 rounded-[24px] font-bold transition-all text-right ${
                activeTab === item.id 
                  ? "bg-white text-orange-600 shadow-xl shadow-gray-200/50 border border-orange-50 scale-[1.02]" 
                  : "text-gray-400 hover:bg-gray-100 hover:text-gray-600"
              }`}
            >
              <div className="flex items-center gap-4">
                <item.icon className={`w-6 h-6 ${activeTab === item.id ? 'text-orange-600' : 'text-gray-300'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="px-2.5 py-1 bg-red-500 text-white text-[10px] font-black rounded-full shadow-md leading-none animate-bounce">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 p-6 md:p-12">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === "services" && (
                <div className="space-y-12">
                  {/* Service Add/Edit Form */}
                  <div className="bg-gray-50 p-8 md:p-10 rounded-[40px] border border-gray-100 shadow-sm relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-orange-100/30 blur-3xl -mr-16 -mt-16" />
                    
                    <h3 className="text-2xl font-bold mb-10 flex items-center gap-4 relative z-10">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner ${editingId ? 'bg-blue-100 text-blue-600' : 'bg-orange-100 text-orange-600'}`}>
                         {editingId ? <Edit2 className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
                      </div>
                      {editingId ? "تعديل الخدمة" : "إضافة شخص أو خدمة جديدة"}
                    </h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-2">
                          <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">الاسم الكامل</label>
                          <input 
                           className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm" 
                           placeholder="مثلاً: د. محمود علي" 
                           value={newService.name || ""}
                           onChange={e => setNewService({...newService, name: e.target.value})}
                         />
                       </div>
                       <div className="space-y-2">
                         <div className="flex items-center justify-between mr-2">
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wide">القسم (التصنيف)</label>
                            <button 
                              onClick={() => setActiveTab('categories')}
                              className="text-[10px] text-blue-600 font-bold hover:underline"
                            >
                               + إضافة قسم جديد
                            </button>
                         </div>
                         <select 
                           className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm appearance-none"
                           value={newService.categoryId || ""}
                           onChange={e => setNewService({...newService, categoryId: e.target.value})}
                         >
                           <option value="">اختر القسم المناسب</option>
                           {data.categories.map((c, idx) => <option key={`opt-cat-${c.id || idx}`} value={c.id}>{c.name}</option>)}
                         </select>
                       </div>
                       <div className="space-y-2">
                         <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">رقم الهاتف للتواصل</label>
                         <input 
                           className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm text-left font-mono" 
                           placeholder="01xxxxxxxxx" 
                           value={newService.phoneNumber || ""}
                           onChange={e => setNewService({...newService, phoneNumber: e.target.value})}
                         />
                       </div>
                       <div className="space-y-2">
                         <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">العنوان بالتفصيل</label>
                         <input 
                           className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm" 
                           placeholder="الشارع، بجوار المعلم..." 
                           value={newService.address || ""}
                           onChange={e => setNewService({...newService, address: e.target.value})}
                         />
                       </div>
                       <div className="space-y-2 md:col-span-2">
                         <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">وصف مختصر للخدمة</label>
                         <textarea 
                           className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm" 
                           placeholder="اكتب هنا تخصص هذا الشخص أو طبيعة الخدمة..."
                           rows={3}
                           value={newService.description || ""}
                           onChange={e => setNewService({...newService, description: e.target.value})}
                         />
                       </div>
                       
                       <div className="md:col-span-2 bg-white p-8 rounded-[36px] border border-gray-100 shadow-sm space-y-8">
                          <div className="flex items-center justify-between">
                             <h4 className="font-bold text-gray-800 flex items-center gap-3">
                               <Image className="w-6 h-6 text-blue-500" />
                               الصور والمعرض الفني
                             </h4>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                             <div className="space-y-4">
                                <label className="text-[10px] font-bold text-gray-400 px-2 uppercase tracking-widest">الصورة الشخصية / الرئيسية</label>
                                <div className="flex gap-3">
                                   <button 
                                     onClick={() => photoInputRef.current?.click()}
                                     className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center hover:bg-blue-100 transition-all active:scale-95 shadow-sm"
                                   >
                                      <Upload className="w-7 h-7" />
                                   </button>
                                   <input type="file" ref={photoInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, 'photo')} />
                                   <input 
                                     className="flex-1 p-4 rounded-2xl bg-gray-50 border-none text-xs font-mono outline-none focus:ring-2 focus:ring-blue-500/20 text-left" 
                                     placeholder="أو ضع رابط مباشر هنا..." 
                                     value={newService.photoUrl}
                                     onChange={e => setNewService({...newService, photoUrl: e.target.value})}
                                   />
                                </div>
                                {newService.photoUrl && (
                                  <div className="relative w-32 h-32 rounded-3xl overflow-hidden border-4 border-gray-50 shadow-md group">
                                     <img src={newService.photoUrl || undefined} className="w-full h-full object-cover" />
                                     <button 
                                       onClick={() => setNewService({...newService, photoUrl: ""})} 
                                       className="absolute top-2 left-2 bg-red-500 text-white rounded-full p-2"
                                     >
                                       <X className="w-4 h-4"/>
                                     </button>
                                   </div>
                                )}
                             </div>

                             <div className="space-y-4">
                                <label className="text-[10px] font-bold text-gray-400 px-2 uppercase tracking-widest">صور إضافية للمعرض</label>
                                <button 
                                   onClick={() => galleryInputRef.current?.click()}
                                   className="w-full p-6 bg-gray-50 text-gray-400 rounded-3xl border-2 border-dashed border-gray-200 hover:border-blue-300 hover:bg-blue-50/30 hover:text-blue-500 transition-all flex flex-col items-center justify-center gap-3 font-bold text-sm"
                                 >
                                    <Plus className="w-8 h-8" />
                                    أضف من استوديو الموبايل
                                 </button>
                                 <input type="file" ref={galleryInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, 'gallery')} />
                                 <div className="flex flex-wrap gap-3 mt-4">
                                    {newService.gallery?.map((img, i) => (
                                      <div key={`edit-gallery-${i}`} className="relative w-16 h-16 rounded-2xl overflow-hidden border-2 border-white shadow-sm group">
                                         <img src={img || undefined} className="w-full h-full object-cover" />
                                         <button 
                                           onClick={() => setNewService({...newService, gallery: newService.gallery?.filter((_, idx) => idx !== i)})} 
                                           className="absolute inset-0 bg-red-500/80 text-white flex items-center justify-center"
                                         >
                                            <Trash2 className="w-4 h-4" />
                                         </button>
                                      </div>
                                    ))}
                                 </div>
                             </div>
                          </div>
                       </div>

                       <div className="flex gap-6 md:col-span-2 mt-6">
                         <button 
                           onClick={addService}
                           className={`flex-1 py-6 text-white rounded-[28px] font-bold text-lg shadow-xl transition-all active:scale-[0.98] ${editingId ? "bg-blue-600 shadow-blue-200" : "bg-gray-950 shadow-gray-200 hover:bg-black"}`}
                         >
                           {editingId ? "حفظ التعديلات" : "إضافة للبرنامج الآن"}
                         </button>
                         {editingId && (
                           <button 
                             onClick={() => { setEditingId(null); setNewService({ id: "", name: "", phoneNumber: "", categoryId: "", description: "", photoUrl: "", gallery: [] }); }}
                             className="px-10 py-6 bg-gray-100 text-gray-500 rounded-[28px] font-bold hover:bg-gray-200"
                           >
                             إلغاء التعديل
                           </button>
                         )}
                       </div>
                    </div>
                  </div>

                  {/* Services List */}
                  <div className="space-y-8 pb-32">
                    <div className="flex items-center justify-between px-2">
                       <h4 className="text-xl font-black text-gray-900 flex items-center gap-3">
                          <div className="w-2 h-6 bg-red-600 rounded-full" />
                          قائمة الخدمات المضافة ({data.services.length})
                       </h4>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {data.services.map((service, idx) => (
                        <div key={`service-card-${service.id || idx}`} className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm hover:shadow-xl transition-all flex flex-col gap-6 relative group overflow-hidden">
                           <div className="flex items-start gap-4">
                              <div className="w-20 h-20 rounded-2xl bg-gray-50 overflow-hidden flex-shrink-0 border-2 border-white shadow-sm">
                                 {service.photoUrl ? (
                                   <img src={service.photoUrl || undefined} className="w-full h-full object-cover" />
                                 ) : (
                                   <div className="w-full h-full flex items-center justify-center text-gray-200">
                                      <Users className="w-10 h-10" />
                                   </div>
                                 )}
                              </div>
                              <div className="flex-1 min-w-0">
                                 <div className="flex items-center gap-2 mb-1">
                                    <span className="px-2.5 py-0.5 bg-blue-50 text-blue-600 rounded-full text-[9px] font-black border border-blue-100">
                                       {data.categories.find(c => c.id === service.categoryId)?.name || "غير مصنف"}
                                    </span>
                                 </div>
                                 <h5 className="font-black text-lg text-gray-900 truncate">{service.name}</h5>
                                 <p className="text-[10px] text-gray-400 font-bold line-clamp-1 mt-1">{service.description || "بدون وصف"}</p>
                              </div>
                           </div>
                           <div className="flex gap-2 pt-4 border-t border-gray-50">
                               <button 
                                 onClick={() => startEditService(service)}
                                 className="flex-[3] py-4 bg-blue-600 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2"
                               >
                                  <Edit2 className="w-4 h-4" />
                                  تعديل
                               </button>
                               <button 
                                 onClick={() => deleteService(service.id)}
                                 className="flex-1 py-4 bg-red-500 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2"
                               >
                                  <Trash2 className="w-4 h-4" />
                               </button>
                           </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "pending" && (
                <div className="space-y-12 animate-in fade-in slide-in-from-bottom-5">
                  <div className="bg-gray-50 p-8 md:p-10 rounded-[40px] border border-gray-100 shadow-sm relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-orange-100/30 blur-3xl -mr-16 -mt-16" />
                    <h3 className="text-2xl font-black mb-2 flex items-center gap-4 relative z-10 text-gray-900">
                      <div className="w-12 h-12 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center shadow-inner">
                        <CheckCircle className="w-6 h-6 animate-pulse" />
                      </div>
                      طلبات الإعلانات المعلقة للمراجعة
                    </h3>
                    <p className="text-gray-400 font-bold text-xs mr-16">
                      هنا الإعلانات والخدمات المضافة بواسطة المستخدمين (العملاء). لن تظهر للعامة حتى تقوم بالموافقة عليها هنا لتنشط في الدليل.
                    </p>
                  </div>

                  <div className="space-y-6">
                    <div className="flex items-center justify-between px-2">
                      <h4 className="text-lg font-black text-gray-900 flex items-center gap-3">
                        <div className="w-2 h-6 bg-orange-500 rounded-full" />
                        الطلبات المعلقة لحاجة مراجعتك ({data.services.filter(s => s.approved === false).length})
                      </h4>
                    </div>

                    {data.services.filter(s => s.approved === false).length === 0 ? (
                      <div className="bg-white p-12 rounded-[32px] border border-gray-100 shadow-sm text-center">
                        <div className="w-16 h-16 bg-green-50 text-green-500 font-bold rounded-full flex items-center justify-center mx-auto mb-4 border border-green-155">
                          <CheckCircle className="w-8 h-8" />
                        </div>
                        <h5 className="font-black text-slate-800 text-lg mb-1">لا توجد طلبات معلقة</h5>
                        <p className="text-gray-400 font-bold text-xs">تمت مراجعة كل طلبات الإعلانات بنجاح!</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {data.services.filter(s => s.approved === false).map((service, idx) => (
                          <div key={`pending-service-card-${service.id || idx}`} className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-md hover:shadow-xl transition-all flex flex-col gap-6 relative group overflow-hidden">
                            <div className="flex items-start gap-4">
                              <div className="w-20 h-20 rounded-2xl bg-gray-50 overflow-hidden flex-shrink-0 border-2 border-white shadow-sm flex items-center justify-center">
                                {service.photoUrl ? (
                                  <img src={service.photoUrl || undefined} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center text-gray-200">
                                    <Users className="w-10 h-10" />
                                  </div>
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1 flex-wrap">
                                  <span className="px-2.5 py-0.5 bg-orange-50 text-orange-600 rounded-full text-[9px] font-black border border-orange-100">
                                    {data.categories.find(c => c.id === service.categoryId)?.name || "غير مصنف"}
                                  </span>
                                  {service.addedBy && (
                                    <span className="text-[10px] text-gray-400 font-sans">بواسطة: {service.addedBy}</span>
                                  )}
                                </div>
                                <h5 className="font-black text-lg text-gray-900 truncate">{service.name}</h5>
                                <p className="text-xs text-gray-550 font-black mt-2 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100 whitespace-pre-wrap">{service.description || "بدون تفاصيل"}</p>
                                <div className="flex items-center gap-2 text-[11px] text-gray-400 font-bold mt-3">
                                  <Phone className="w-3.5 h-3.5 text-orange-500" />
                                  <span className="font-mono">{service.phoneNumber}</span>
                                  {service.address && (
                                    <>
                                      <span className="text-gray-200">|</span>
                                      <MapPin className="w-3.5 h-3.5 text-blue-500" />
                                      <span>{service.address}</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="flex gap-2 pt-4 border-t border-gray-150">
                              <button 
                                onClick={async () => {
                                  setIsSaving(true);
                                  const payload = {
                                    ...service,
                                    approved: true,
                                    updatedAt: new Date().toISOString()
                                  };
                                  const success = await onAdminAction('update', 'services', service.id, payload);
                                  setIsSaving(false);
                                  if (success) {
                                    showStatus("تمت الموافقة على الإعلان ونشره بنجاح!");
                                  }
                                }}
                                className="flex-[3] py-4 bg-green-600 hover:bg-green-700 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-green-100 transition-colors cursor-pointer"
                              >
                                <CheckCircle className="w-4 h-4" />
                                موافقة ونشر الإعلان
                              </button>
                              <button 
                                onClick={async () => {
                                  if (window.confirm("هل أنت متأكد من رفض وحذف هذا الطلب؟")) {
                                    setIsSaving(true);
                                    const success = await onAdminAction('delete', 'services', service.id);
                                    setIsSaving(false);
                                    if (success) {
                                      showStatus("تم رفض وحذف الطلب");
                                    }
                                  }
                                }}
                                className="flex-1 py-4 bg-red-500 hover:bg-red-600 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                                رفض
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {activeTab === "categories" && (
                <div className="space-y-12">
                  <div className="bg-gray-50 p-10 rounded-[40px] border border-gray-100 shadow-sm relative overflow-hidden">
                     <div className="absolute top-0 right-0 w-32 h-32 bg-blue-100/30 blur-3xl -mr-16 -mt-16" />
                     <h3 className="text-2xl font-bold mb-10 flex items-center gap-4 relative z-10">
                       <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center shadow-inner">
                         <Grid className="w-6 h-6" />
                       </div>
                       إدارة أقسام الخدمات
                     </h3>

                     <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-end">
                       <div className="md:col-span-4 space-y-2">
                         <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">اسم القسم الجديد</label>
                         <input 
                            className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm" 
                            placeholder="مثلاً: صيدليات، كهربائي، مطاعم..." 
                            value={newCategory.name}
                            onChange={e => setNewCategory({...newCategory, name: e.target.value})}
                          />
                       </div>
                       <div className="md:col-span-3 space-y-2">
                          <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">اختر أيقونة مناسبة</label>
                          <select 
                            className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm appearance-none"
                            value={newCategory.icon}
                            onChange={e => setNewCategory({...newCategory, icon: e.target.value})}
                          >
                            <option value="Store">دكان / محل / سوبر ماركت</option>
                            <option value="Utensils">مطعم / أكل / وجبات</option>
                            <option value="Pizza">معجنات / بيتزا / مخبز</option>
                            <option value="Coffee">كافيه / قهوة / عصير</option>
                            <option value="Stethoscope">طبيب / صيدلية / عيادة</option>
                            <option value="Smartphone">موبايلات / كمبيوتر / صيانة</option>
                            <option value="Car">سيارات / ميكانيكا / غيار</option>
                            <option value="Bus">مواصلات / توكتوك / تاكسي</option>
                            <option value="Truck">شحن / نقل / ونش</option>
                            <option value="Scissors">حلاقة / تجميل / كوافير</option>
                            <option value="Shirt">ملابس / خياطة / أحذية</option>
                            <option value="Zap">كهرباء / أجهزة / تكييف</option>
                            <option value="Droplets">سباكة / مياه / فلاتر</option>
                            <option value="Hammer">بناء / مقاولات / سيراميك</option>
                            <option value="Wrench">صيانة وتصليح / ورشة</option>
                            <option value="GraduationCap">تعليم / دروس / حضانة</option>
                            <option value="Dumbbell">جيم / رياضة / كمال أجسام</option>
                            <option value="Camera">تصوير / ميديا / استوديو</option>
                            <option value="Paintbrush">نقاشة / ديكور / دهانات</option>
                            <option value="Tv">إلكترونيات / دش / ريسيفر</option>
                            <option value="Gamepad2">ألعاب / بلايستيشن / سايبر</option>
                            <option value="Briefcase">وظائف ومهن / مكتب</option>
                            <option value="Home">عقارات / أراضي / شقق</option>
                            <option value="Heart">صحة وجمال / معمل</option>
                            <option value="ShoppingBag">تسوق / هدايا / ألعاب</option>
                            <option value="Baby">مستلزمات أطفال</option>
                            <option value="Fish">أسماك / مأكولات بحرية</option>
                            <option value="Beef">جزارة / لحوم</option>
                            <option value="Grape">فاكهة / خضروات</option>
                            <option value="Flower2">زهور / مشاتل / زراعة</option>
                            <option value="Lightbulb">أدوات منزلية / خردوات</option>
                            <option value="Library">مكتبة / تصوير مستندات</option>
                            <option value="Shield">أمن / شرطة / بلاغات</option>
                            <option value="Trash2">خدمات نظافة / بيئة</option>
                            <option value="Cloud">خدمات جوية / سفر / حجز</option>
                            <option value="Coins">مالية / صرافة / بنك</option>
                            <option value="Book">كتب / ثقافة / علم</option>
                            <option value="Mic2">إذاعة / مناسبات / أفراح</option>
                            <option value="Palmtree">منتزه / حديقة / خروجات</option>
                          </select>
                       </div>
                       <div className="md:col-span-3 space-y-2">
                          <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">صورة القسم (خلفية)</label>
                          <div className="flex gap-2">
                             <button 
                               onClick={() => categoryImageInputRef.current?.click()}
                               className="w-14 h-14 bg-white border border-gray-100 rounded-2xl flex items-center justify-center text-blue-600 hover:bg-blue-50 transition-all shadow-sm"
                             >
                                <Upload className="w-5 h-5" />
                             </button>
                             <input type="file" ref={categoryImageInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, 'category')} />
                             <div className="flex-1 min-w-0">
                               <input 
                                 className="w-full h-14 p-4 rounded-2xl bg-white border border-gray-100 font-mono text-[10px] outline-none focus:ring-2 focus:ring-blue-500/20 text-left" 
                                 placeholder="رابط الصورة..." 
                                 value={newCategory.image || ""}
                                 onChange={e => setNewCategory({...newCategory, image: e.target.value})}
                               />
                             </div>
                          </div>
                       </div>
                       <div className="md:col-span-2">
                          <button onClick={addCategory} className="w-full py-5 bg-blue-600 text-white rounded-[24px] font-bold shadow-xl flex items-center justify-center gap-2 transition-all active:scale-95">
                             <Plus className="w-5 h-5" />
                             إضافة
                          </button>
                       </div>
                    </div>
                    {newCategory.image && (
                      <div className="mt-4 w-32 h-20 rounded-2xl overflow-hidden border-2 border-white shadow-md relative">
                         <img src={newCategory.image || undefined} className="w-full h-full object-cover" />
                         <button onClick={() => setNewCategory({...newCategory, image: ""})} className="absolute top-1 left-1 bg-red-500 text-white rounded-full p-1 shadow-md">
                            <X className="w-3 h-3" />
                         </button>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[...data.categories].sort((a,b) => a.order - b.order).map((cat, idx) => (
                      <div key={`cat-admin-${idx}`} className="p-8 bg-white border border-gray-50 rounded-[40px] flex flex-col items-center gap-4 shadow-sm relative group overflow-hidden">
                        {cat.image ? (
                          <div className="absolute inset-0 z-0">
                            <img src={cat.image || undefined} className="w-full h-full object-cover opacity-10" />
                            <div className="absolute inset-0 bg-gradient-to-b from-white/80 to-white" />
                          </div>
                        ) : null}
                        <div className="w-16 h-16 bg-gray-50 rounded-[24px] flex items-center justify-center relative z-10">
                          <DynamicIcon name={cat.icon} className="w-9 h-9 text-gray-300" />
                        </div>
                        <div className="text-center relative z-10">
                          <p className="font-black text-gray-900 text-lg">{cat.name}</p>
                        </div>
                        <button 
                           onClick={async () => {
                             if (window.confirm(`هل أنت متأكد من حذف قسم "${cat.name}" نهائياً من الدليل بالكامل؟`)) {
                               setIsSaving(true);
                               const success = await onAdminAction('delete', 'categories', cat.id);
                               setIsSaving(false);
                               if (success) {
                                 showStatus("تم حذف القسم بنجاح!");
                               }
                             }
                           }}
                           className="w-full py-3 bg-red-50 hover:bg-red-600 text-red-500 hover:text-white rounded-2xl font-black text-[11px] flex items-center justify-center gap-2 transition-all relative z-10 cursor-pointer border border-red-100"
                        >
                           <Trash2 className="w-4 h-4 animate-shake" />
                           حذف القسم بالكامل
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "news" && (
                <div className="space-y-12">
                  <div className="bg-gray-50 p-10 rounded-[40px] border border-gray-100 shadow-sm relative overflow-hidden">
                     <div className="absolute top-0 right-0 w-32 h-32 bg-red-100/30 blur-3xl -mr-16 -mt-16" />
                     <h3 className="text-2xl font-bold mb-10 flex items-center gap-4 relative z-10">
                       <div className="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center shadow-inner">
                         <Bell className="w-6 h-6" />
                       </div>
                       نشر أخبار وتنبيهات
                     </h3>

                     <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                           <div className="md:col-span-3 space-y-2">
                              <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">عنوان الخبر</label>
                              <input 
                                 className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-red-500/5 focus:border-red-500 transition-all shadow-sm" 
                                 placeholder="ماذا يحدث في القرية؟" 
                                 value={newNews.title || ""}
                                 onChange={e => setNewNews({...newNews, title: e.target.value})}
                               />
                           </div>
                           <div className="space-y-2">
                              <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">نوع التنبيه</label>
                              <select 
                                 className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-red-500/5 focus:border-red-500 transition-all shadow-sm"
                                 value={newNews.type || "normal"}
                                 onChange={e => setNewNews({...newNews, type: e.target.value as any})}
                               >
                                 <option value="normal">خبر عادي</option>
                                 <option value="urgent">عاجل ⚠️</option>
                                 <option value="event">فعالية 🎉</option>
                               </select>
                           </div>
                        </div>
                        <div className="space-y-2">
                           <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">تفاصيل الخبر</label>
                           <textarea 
                             className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-red-500/5 focus:border-red-500 transition-all shadow-sm" 
                             placeholder="اكتب تفاصيل الخبر هنا..." 
                             rows={4}
                             value={newNews.content || ""}
                             onChange={e => setNewNews({...newNews, content: e.target.value})}
                           />
                        </div>
                        <button onClick={addNews} className="w-full py-5 bg-red-600 text-white rounded-[24px] font-bold shadow-xl hover:bg-red-700 transition-all">
                           نشر الخبر الآن
                        </button>
                      </div>
                   </div>

                   <div className="space-y-6">
                      {data.news.map((n, idx) => (
                        <div key={`news-${idx}`} className="p-8 bg-white border border-gray-100 rounded-[40px] flex items-center justify-between shadow-sm">
                          <div className="flex-1 space-y-3">
                             <div className="flex items-center gap-3">
                                <span className="px-3 py-1 bg-gray-50 text-gray-500 rounded-full text-[10px] font-bold uppercase tracking-widest">{n.type}</span>
                                <span className="text-[10px] text-gray-400 font-bold">{new Date(n.createdAt).toLocaleString('ar-EG')}</span>
                             </div>
                             <p className="font-black text-xl text-blue-900 leading-tight">{n.title}</p>
                             <p className="text-sm text-gray-500 font-bold">{n.content}</p>
                          </div>
                          <button 
                             onClick={() => onAdminAction('delete', 'news', n.id)}
                             className="px-6 py-4 bg-red-50 text-red-500 rounded-[24px] hover:bg-red-500 hover:text-white transition-all shadow-sm font-black text-xs"
                          >
                             حذف الخبر
                          </button>
                        </div>
                      ))}
                   </div>
                </div>
              )}

              {activeTab === "notifications" && (
                <div className="space-y-12">
                   <div className="flex items-center justify-between">
                      <h2 className="text-3xl font-black text-gray-900 tracking-tight">إدارة الإشعارات (FCM)</h2>
                      <div className="flex items-center gap-3 bg-green-50 px-6 py-3 rounded-2xl border border-green-100">
                         <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                         <span className="text-sm font-bold text-green-700">السيرفر متصل وجاهز</span>
                      </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="bg-gray-50 p-10 rounded-[40px] border border-gray-100 shadow-sm relative overflow-hidden">
                         <div className="absolute top-0 right-0 w-32 h-32 bg-blue-100/30 blur-3xl -mr-16 -mt-16" />
                         <h3 className="text-2xl font-bold mb-10 flex items-center gap-4 relative z-10">
                           <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center shadow-inner">
                             <LucideIcons.Send className="w-6 h-6" />
                           </div>
                           إرسال إشعار عام للمشتركين
                         </h3>
                         
                         <p className="text-gray-400 font-bold text-sm mb-8 leading-relaxed">
                            سيتم إرسال هذا الإشعار لجميع مستخدمي أندرويد وكروم الذين وافقوا على استلام التنبيهات. 
                         </p>

                         <div className="space-y-6">
                            <div className="space-y-2">
                               <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">عنوان الإشعار</label>
                               <input 
                                  className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm" 
                                  placeholder="مثلاً: خبر عاجل!" 
                                />
                            </div>
                            <div className="space-y-2">
                               <label className="text-xs font-bold text-gray-400 mr-2 uppercase tracking-wide">نص الرسالة</label>
                               <textarea 
                                  className="w-full p-5 rounded-3xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all shadow-sm" 
                                  placeholder="اكتب هنا ما تريد أن يظهر في التنبيه..." 
                                  rows={3}
                                />
                            </div>
                            <button 
                              onClick={() => showStatus("سيتم تفعيل الإرسال مع تحديث السيرفر القادم")}
                              className="w-full py-5 bg-blue-600 text-white rounded-[24px] font-bold shadow-xl hover:bg-blue-700 transition-all flex items-center justify-center gap-3"
                            >
                               <Bell className="w-5 h-5" />
                               إرسال التنبيه الآن
                            </button>
                         </div>
                      </div>

                      <div className="bg-white p-10 rounded-[40px] border border-gray-50 shadow-sm space-y-8">
                         <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-gray-900 text-white rounded-2xl flex items-center justify-center shadow-lg">
                               <Shield className="w-6 h-6" />
                            </div>
                            <h4 className="font-bold text-gray-900">سجل المشتركين الفعالين</h4>
                         </div>
                         
                         <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                            <div className="bg-gray-50 p-6 rounded-[28px] border border-gray-100 flex items-center justify-between">
                               <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                                     <Smartphone className="w-5 h-5 text-gray-400" />
                                  </div>
                                  <div>
                                     <p className="font-black text-gray-900 text-sm">جهاز (نشط الآن)</p>
                                     <p className="text-[10px] text-gray-400 font-bold">تم تسجيل الـ Token بنجاح</p>
                                  </div>
                               </div>
                               <div className="w-2 h-2 bg-green-500 rounded-full" />
                            </div>
                            <p className="text-center text-[10px] text-gray-300 font-bold py-4">يتم ربط الـ FCM Token تلقائياً عند فتح البرنامج وموافقة المستخدم</p>
                         </div>
                      </div>
                   </div>
                </div>
              )}

              {activeTab === "feedback" && (
                <div className="space-y-12">
                   <h2 className="text-3xl font-black text-gray-900 tracking-tight">رسائل العملاء</h2>
                   <div className="grid grid-cols-1 gap-6">
                      {!data.comments || data.comments.length === 0 ? (
                        <p className="text-gray-400 text-center py-20 font-bold">لا توجد رسائل حالياً</p>
                      ) : (
                        data.comments.map((comment) => (
                          <div key={comment.id} className="bg-white p-8 rounded-[40px] border border-gray-50 shadow-sm relative">
                             <div className="flex items-center gap-4 mb-6">
                                <div className="w-12 h-12 bg-blue-500 text-white rounded-2xl flex items-center justify-center font-black">
                                   {comment.userName.charAt(0)}
                                </div>
                                <div>
                                   <p className="font-black text-gray-900">{comment.userName}</p>
                                   <p className="text-[11px] text-gray-400">{new Date(comment.createdAt).toLocaleString('ar-EG')}</p>
                                </div>
                             </div>
                             <p className="text-gray-600 font-bold leading-relaxed">{comment.content}</p>
                             {comment.imageUrl && (
                               <div className="mt-4 rounded-3xl overflow-hidden max-h-64 border border-gray-150 bg-slate-50 flex items-center justify-center p-2 mb-2">
                                 <img 
                                   src={comment.imageUrl} 
                                   className="max-w-full max-h-60 rounded-2xl object-contain shadow-sm" 
                                   alt="صورة المنتج المرفقة" 
                                   referrerPolicy="no-referrer"
                                 />
                               </div>
                             )}
                             <div className="absolute top-8 left-8 flex gap-2">
                                <button 
                                   onClick={() => setCommentToConvert(comment)}
                                   className="p-3 bg-blue-50 text-blue-500 rounded-xl hover:bg-blue-500 hover:text-white transition-all"
                                   title="تحويل إلى خدمة"
                                >
                                   <Download className="w-5 h-5" />
                                </button>
                                <button 
                                   onClick={() => onAdminAction('delete', 'comments', comment.id)}
                                   className="p-3 bg-red-50 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all"
                                   title="حذف الرسالة"
                                >
                                   <Trash2 className="w-5 h-5" />
                                </button>
                             </div>
                          </div>
                        ))
                      )}
                   </div>
                </div>
              )}

              {activeTab === "settings" && (
                <div className="space-y-12">
                   <div className="flex items-center justify-between">
                      <h2 className="text-3xl font-black text-gray-900 tracking-tight">إعدادات التطبيق العامة</h2>
                      <button 
                         onClick={async () => {
                           setIsSaving(true);
                           const success = await onAdminAction('update', 'settings', 'global', tempSettings);
                           setIsSaving(false);
                           if (success) showStatus("تم حفظ الإعدادات بنجاح");
                         }}
                         className="flex items-center gap-3 bg-blue-600 text-white px-8 py-4 rounded-[24px] font-black shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all active:scale-95"
                      >
                         <Save className="w-5 h-5" />
                         حفظ التغييرات
                      </button>
                   </div>

                   <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                      {/* Splash Screen Customization */}
                      <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-8 rounded-[40px] shadow-2xl relative overflow-hidden group">
                         <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
                         <div className="absolute bottom-0 left-0 w-24 h-24 bg-black/10 rounded-full -ml-12 -mb-12 group-hover:scale-125 transition-transform duration-500" />
                         
                         <h4 className="text-white font-black flex items-center gap-3 mb-8 relative z-10 text-xl">
                            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                               <Smartphone className="w-6 h-6 text-white" />
                            </div>
                            واجهة البداية (Splash Screen)
                         </h4>
                         
                         <div className="space-y-6 relative z-10">
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase tracking-widest text-blue-100 ml-2">العنوان الكبير</label>
                               <input 
                                  className="w-full bg-white/10 border border-white/20 p-4 rounded-2xl font-bold outline-none focus:bg-white text-blue-900 transition-all placeholder:text-white/30" 
                                  placeholder="مثلاً: عزبة الشيخ بطيخ"
                                  value={tempSettings.splashTitle || ""} 
                                  onChange={e => setTempSettings({...tempSettings, splashTitle: e.target.value})} 
                                />
                            </div>
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase tracking-widest text-blue-100 ml-2">العنوان الفرعي</label>
                               <input 
                                  className="w-full bg-white/10 border border-white/20 p-4 rounded-2xl font-bold outline-none focus:bg-white text-blue-900 transition-all placeholder:text-white/30" 
                                  placeholder="مثلاً: دليل الخدمات الشامل"
                                  value={tempSettings.splashSubtitle || ""} 
                                  onChange={e => setTempSettings({...tempSettings, splashSubtitle: e.target.value})} 
                                />
                            </div>
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase tracking-widest text-blue-100 ml-2">رقم الهاتف (يظهر في البداية)</label>
                               <input 
                                  className="w-full bg-white/10 border border-white/20 p-4 rounded-2xl font-bold outline-none focus:bg-white text-blue-900 transition-all placeholder:text-white/30 text-left font-mono" 
                                  placeholder="رقم الهاتف (اختياري)"
                                  value={tempSettings.splashPhone || ""} 
                                  onChange={e => setTempSettings({...tempSettings, splashPhone: e.target.value})} 
                                />
                            </div>
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase tracking-widest text-blue-100 ml-2">أيقونة الواجهة (Splash Icon)</label>
                               <div className="flex gap-3">
                                  <button 
                                    onClick={() => splashInputRef.current?.click()}
                                    className="w-14 h-14 bg-white/10 text-white rounded-2xl flex items-center justify-center hover:bg-white/20 transition-all active:scale-95 border border-white/10"
                                  >
                                     <Upload className="w-5 h-5" />
                                  </button>
                                  <input type="file" ref={splashInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, 'splash')} />
                                  <input 
                                    className="flex-1 bg-white/10 border border-white/20 p-4 rounded-2xl font-bold outline-none focus:bg-white text-blue-900 transition-all text-left font-mono text-xs placeholder:text-white/30" 
                                    placeholder="أو ضع رابط الأيقونة هنا..." 
                                    value={tempSettings.splashIconUrl}
                                    onChange={e => setTempSettings({...tempSettings, splashIconUrl: e.target.value})}
                                  />
                               </div>
                               {tempSettings.splashIconUrl && (
                                 <div className="mt-2 w-20 h-20 rounded-2xl overflow-hidden border-2 border-white/20 relative group">
                                    <img src={tempSettings.splashIconUrl} className="w-full h-full object-cover" />
                                    <button onClick={() => setTempSettings({...tempSettings, splashIconUrl: ""})} className="absolute inset-0 bg-red-500/80 text-white opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                       <X className="w-5 h-5" />
                                    </button>
                                 </div>
                               )}
                            </div>
                         </div>
                         
                         <div className="mt-8 pt-6 border-t border-white/10 flex items-center justify-center gap-2 text-white/40 text-[10px] font-bold uppercase tracking-tighter">
                            <span>تظهر في واجهة البداية وكرأس للصفحة</span>
                         </div>
                      </div>

                      <div className="bg-gray-50 p-8 rounded-[40px] border border-gray-100 space-y-6">
                         <h4 className="font-black text-blue-900 flex items-center gap-2">
                            <Type className="w-5 h-5" />
                            النصوص والعناوين
                         </h4>
                         <div className="space-y-4">
                                                         <div className="space-y-4">
                                <label className="text-[10px] font-bold text-gray-400 mr-2 uppercase tracking-widest">شعار البرنامج (Logo) والتحكم في المظهر</label>
                                <div className="flex gap-4">
                                   <button 
                                     type="button"
                                     onClick={() => logoInputRef.current?.click()}
                                     className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center hover:bg-blue-100 transition-all active:scale-95 shadow-sm"
                                   >
                                      <Upload className="w-7 h-7" />
                                   </button>
                                   <input type="file" ref={logoInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, 'logo')} />
                                   <input 
                                     className="flex-1 p-5 rounded-2xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all text-left font-mono text-xs" 
                                     placeholder="أو ضع رابط الشعار هنا..." 
                                     value={tempSettings.logoUrl}
                                     onChange={e => setTempSettings({...tempSettings, logoUrl: e.target.value})}
                                   />
                                   <div className="w-16 h-16 bg-gray-100 rounded-full shadow-sm overflow-hidden flex-shrink-0 border border-white flex items-center justify-center text-white text-[8px] font-black leading-tight text-center relative">
                                      <img 
                                         src={tempSettings.logoUrl || "https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=512&h=512&auto=format&fit=crop&fm=png"} 
                                         className="w-full h-full object-cover" 
                                         alt="Logo Preview"
                                      />
                                      {!tempSettings.hideLogoOverlay && (!tempSettings.logoUrl ? (
                                        <div className="absolute inset-0 flex items-center justify-center p-1">
                                           <div className="bg-white/95 backdrop-blur-sm px-1 rounded shadow-lg border border-blue-50 flex flex-col items-center scale-75">
                                              <span className="text-blue-900 font-extrabold whitespace-nowrap text-[6px]">{tempSettings.splashTitle || "عزبة الشيخ بطيخ"}</span>
                                           </div>
                                        </div>
                                      ) : (
                                        <div className="absolute bottom-0 left-0 right-0 h-[22px] bg-white flex flex-col items-center justify-center border-t border-gray-50 overflow-hidden select-none pb-0.5 scale-75 origin-bottom">
                                          <span className="text-[6.5px] font-black text-blue-900 leading-none block">{tempSettings.splashTitle || "عزبة الشيخ بطيخ"}</span>
                                        </div>
                                      ))}
                                      <div className="absolute inset-0 bg-blue-600/10 pointer-events-none" />
                                   </div>
                                </div>

                                {/* Custom Pre-designed Beautiful Presets */}
                                <div className="bg-white p-5 rounded-3xl border border-gray-100 space-y-3 text-right">
                                   <span className="text-xs font-black text-gray-500 flex items-center gap-1.5 justify-start">
                                      <LucideIcons.Sparkles className="w-4 h-4 text-blue-500 animate-pulse" />
                                      اختر خلفية رائعة للشعار فوراً (بدون رفع):
                                   </span>
                                   <div className="flex gap-3 overflow-x-auto pb-2 pt-1 scrollbar-none snap-x" style={{ direction: 'rtl' }}>
                                      {[
                                        {
                                          name: "الهلال والنيل الريفي",
                                          url: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=512&h=512&auto=format&fit=crop"
                                        },
                                        {
                                          name: "الحقول الخضراء",
                                          url: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=512&h=512&auto=format&fit=crop&fm=png"
                                        },
                                        {
                                          name: "النخيل والغروب الساحر",
                                          url: "https://images.unsplash.com/photo-1542401886-65d6c61db217?q=80&w=512&h=512&auto=format&fit=crop"
                                        },
                                        {
                                          name: "مسجد هادئ وزخارف",
                                          url: "https://images.unsplash.com/photo-1564507592333-c60657eea523?q=80&w=512&h=512&auto=format&fit=crop"
                                        },
                                        {
                                          name: "شعار أزرق مذهب",
                                          url: "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?q=80&w=512&h=512&auto=format&fit=crop"
                                        }
                                      ].map((preset, index) => {
                                         const isSelected = tempSettings.logoUrl === preset.url;
                                         return (
                                           <button
                                             key={index}
                                             type="button"
                                             onClick={() => setTempSettings({...tempSettings, logoUrl: preset.url})}
                                             className={`flex-shrink-0 snap-center flex flex-col items-center gap-1.5 p-2 rounded-2xl border transition-all ${isSelected ? 'border-blue-500 bg-blue-50/50 scale-95 shadow-sm' : 'border-gray-100 bg-gray-50/50 hover:bg-gray-50'}`}
                                           >
                                             <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-white shadow-sm relative">
                                               <img src={preset.url} className="w-full h-full object-cover" />
                                               {isSelected && (
                                                 <div className="absolute inset-0 bg-blue-600/30 flex items-center justify-center">
                                                     <CheckCircle className="w-5 h-5 text-white" />
                                                  </div>
                                                )}
                                              </div>
                                              <span className="text-[9px] font-bold text-gray-500 whitespace-nowrap">{preset.name}</span>
                                            </button>
                                          );
                                       })}
                                    </div>
                                 </div>

                                 <div className="flex items-center justify-between p-4 bg-white rounded-3xl border border-gray-100 mt-4">
                                   <div>
                                      <h5 className="font-bold text-gray-950 text-xs">إخفاء تراكب الشعار</h5>
                                      <span className="text-[9px] text-gray-400 font-bold block mt-0.5">شعار نظيف ومريح للعين، بدون تراكب اسم القرية ورقم الموبايل فوق خلفية الشعار بصفحة البداية.</span>
                                   </div>
                                   <button
                                     type="button"
                                     onClick={() => setTempSettings({ ...tempSettings, hideLogoOverlay: !tempSettings.hideLogoOverlay })}
                                     className={`w-14 h-8 rounded-full transition-colors duration-300 relative flex items-center flex-shrink-0 ${tempSettings.hideLogoOverlay ? 'bg-blue-600 justify-end px-1' : 'bg-gray-200 justify-start px-1'}`}
                                   >
                                      <motion.div 
                                        layout 
                                        className="w-6 h-6 rounded-full bg-white shadow-sm"
                                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                                      />
                                   </button>
                                </div>
                             </div>
                          </div>

                          <div className="space-y-4">
                             <div className="space-y-2">
                                <label className="text-[10px] font-bold text-gray-400 mr-2 uppercase tracking-widest">اسم التطبيق</label>
                                <input 
                                  className="w-full p-5 rounded-2xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all font-black text-lg" 
                                  value={tempSettings.appName}
                                  onChange={e => setTempSettings({...tempSettings, appName: e.target.value})}
                                />
                             </div>
                             <div className="space-y-2">
                                <label className="text-[10px] font-bold text-gray-400 mr-2 uppercase tracking-widest">رابط ملف التطبيق المباشر لأندرويد (APK / AAB)</label>
                                <input 
                                  className="w-full p-5 rounded-2xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all text-left font-mono text-xs" 
                                  placeholder="https://drive.google.com/..."
                                  value={tempSettings.apkDownloadUrl || ""}
                                  onChange={e => setTempSettings({...tempSettings, apkDownloadUrl: e.target.value})}
                                />
                                <span className="text-[10px] text-gray-400 font-bold mr-2 block mt-1">رابط تحميل ملف الـ APK المرفوع على جوجل درايف لتنزيل التطبيق وتثبيته مباشرة.</span>
                             </div>
                             <div className="space-y-2">
                                <label className="text-[10px] font-bold text-gray-400 mr-2 uppercase tracking-widest">رسالة الترحيب</label>
                                <input 
                                  className="w-full p-5 rounded-2xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
                                  value={tempSettings.welcomeMessage}
                                  onChange={e => setTempSettings({...tempSettings, welcomeMessage: e.target.value})}
                                />
                             </div>

                          </div>
                       </div>

                       <div className="bg-gray-50 p-8 rounded-[40px] border border-gray-100 space-y-6">
                         <h4 className="font-black text-blue-900 flex items-center gap-2">
                            <Shield className="w-5 h-5" />
                            هوية المطور والبرنامج
                         </h4>
                         <div className="space-y-4">
                            <div className="space-y-2">
                               <label className="text-[10px] font-bold text-gray-400 mr-2 uppercase tracking-widest">اسم المطور</label>
                               <input 
                                 className="w-full p-5 rounded-2xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all" 
                                 value={tempSettings.developerName}
                                 onChange={e => setTempSettings({...tempSettings, developerName: e.target.value})}
                               />
                            </div>
                            <div className="space-y-2">
                               <label className="text-[10px] font-bold text-gray-400 mr-2 uppercase tracking-widest">صورة المطور (رابط)</label>
                               <div className="flex gap-4">
                                  <input 
                                    className="flex-1 p-5 rounded-2xl bg-white border border-gray-100 font-bold outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all text-left font-mono text-xs" 
                                    value={tempSettings.developerImageUrl}
                                    onChange={e => setTempSettings({...tempSettings, developerImageUrl: e.target.value})}
                                  />
                                  <div className="w-16 h-16 bg-white rounded-2xl shadow-sm overflow-hidden flex-shrink-0 border border-gray-100">
                                     <img src={tempSettings.developerImageUrl || undefined} className="w-full h-full object-cover" />
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <AnimatePresence>
        {commentToConvert && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4 text-right"
            dir="rtl"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white rounded-[32px] w-full max-w-lg overflow-hidden shadow-2xl"
            >
              <div className="p-8 border-b border-gray-100 flex items-center justify-between">
                 <div>
                   <h3 className="text-xl font-black text-gray-900">إضافة الطلب كخدمة</h3>
                   <p className="text-sm text-gray-500 mt-1">اختر القسم الذي تريد إضافة الطلب فيه</p>
                 </div>
                 <button onClick={() => setCommentToConvert(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                   <X className="w-6 h-6 text-gray-400" />
                 </button>
              </div>
              <div className="p-8 max-h-[60vh] overflow-y-auto grid grid-cols-1 gap-3">
                 {[...data.categories].sort((a,b) => a.order - b.order).map(cat => (
                   <button
                     key={cat.id}
                     onClick={async () => {
                       const serviceId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
                       const newServicePayload = {
                         id: serviceId,
                         name: `طلب: ${commentToConvert.userName}`,
                         categoryId: cat.id,
                         description: commentToConvert.content, photoUrl: commentToConvert.imageUrl || "",
                         phoneNumber: "",
                         address: "إضافة تلقائية من الرسائل",
                         addedBy: managerName || "مدير التطبيق",
                         createdAt: new Date().toISOString(),
                         updatedAt: new Date().toISOString()
                       };
                       
                       const success = await onAdminAction('add', 'services', serviceId, newServicePayload);
                       if (success) {
                         setCommentToConvert(null);
                         showStatus(`تمت الإضافة بنجاح في قسم ${cat.name}`);
                       }
                     }}
                     className="flex items-center gap-4 p-5 bg-gray-50 hover:bg-blue-50 hover:text-blue-600 rounded-2xl transition-all border border-transparent hover:border-blue-100 text-right group"
                   >
                     <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                       <DynamicIcon name={cat.icon} className="w-6 h-6 text-blue-500" />
                     </div>
                     <span className="font-bold text-lg">{cat.name}</span>
                   </button>
                 ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {saveStatus && (
          <motion.div 
            initial={{ opacity: 0, y: 50, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 50, x: "-50%" }}
            className="fixed bottom-12 left-1/2 bg-gray-900 text-white px-8 py-5 rounded-[24px] shadow-2xl z-[100] flex items-center gap-4"
          >
             <CheckCircle className="w-5 h-5 text-green-500" />
             <span className="font-bold text-sm">{saveStatus}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
