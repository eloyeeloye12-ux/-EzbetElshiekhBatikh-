import React from "react";
import { ArrowRight, ShieldCheck, HelpCircle, Mail, Globe, CheckCircle2 } from "lucide-react";

interface PrivacyPolicyProps {
  onBack: () => void;
  appName: string;
  developerName: string;
}

export default function PrivacyPolicy({ onBack, appName, developerName }: PrivacyPolicyProps) {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 p-6 flex flex-col items-center">
      <div className="w-full max-w-2xl bg-white rounded-3xl p-8 shadow-sm border border-slate-100 mt-4 mb-12">
        
        {/* Header */}
        <div className="flex items-center gap-4 mb-8 border-b border-slate-100 pb-6">
          <button 
            onClick={onBack}
            className="w-12 h-12 bg-slate-50 hover:bg-slate-100 rounded-2xl flex items-center justify-center transition-all text-slate-650"
          >
            <ArrowRight className="w-6 h-6" />
          </button>
          <div>
            <div className="flex items-center gap-1.5 text-blue-600 font-black text-xs mb-1 bg-blue-50 px-3 py-1 rounded-full w-fit">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>وثيقة معتمدة ومطابقة لمتطلبات Google Play</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900">سياسة الخصوصية (Privacy Policy)</h1>
          </div>
        </div>

        {/* Introduction */}
        <div className="space-y-6 text-sm text-slate-600 leading-relaxed text-right">
          <p>
            تعد خصوصية زوارنا ومستخدمينا ذات أهمية قصوى بالنسبة لنا. توضح هذه الوثيقة أنواع المعلومات الشخصية التي يتلقاها ويجمعها تطبيق <strong className="text-slate-900">"{appName}"</strong> وكيفية استخدامها وحمايتها، وذلك امتثالاً لقوانين حماية البيانات ومعايير متجر <strong className="text-slate-900">Google Play Store</strong>.
          </p>

          <div className="bg-blue-50/50 p-5 rounded-2xl border border-blue-100 space-y-2">
            <h3 className="font-black text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600" />
              <span>ملخص سريع للخصوصية:</span>
            </h3>
            <p className="text-xs font-bold text-slate-600">
              تطبيقنا هو دليل خدمات عام، لا نقوم بمشاركة أي من بياناتك مع أطراف خارجية، وجميع البيانات المعروضة في التطبيق هي أرقام وعناوين عامة مقدمة لخدمة المجتمع، والتطبيق آمن تمامًا بنسبة 100%.
            </p>
          </div>

          {/* Section 1 */}
          <div className="space-y-2">
            <h2 className="text-base font-black text-slate-900">1. جمع المعلومات واستخدامها</h2>
            <p>
              نحن لا نطلب أو نجمع أي بيانات تعريف شخصية (PII) مثل اسمك الكامل أو عنوان بريدك الإلكتروني أو أرقام هواتفك لتصفح الخدمات الأساسية في التطبيق. إذا قمت بتقديم اقتراح لإضافة خدمة جديدة، يتم معالجة البيانات فقط لغرض مراجعة الاقتراح ونشره في الدليل العام بعد موافقة الإدارة.
            </p>
          </div>

          {/* Section 2 */}
          <div className="space-y-2">
            <h2 className="text-base font-black text-slate-905">2. الأذونات المطلوبة (App Permissions)</h2>
            <p>
              قد يطلب التطبيق أذونات محددة لتقديم ميزات تفاعلية أفضل:
            </p>
            <ul className="list-disc list-inside pr-4 space-y-1.5 text-xs font-bold text-slate-650">
              <li><strong>الإشعارات (Notifications):</strong> لإرسال تنبيهات هامة لك بخصوص عيادات الأطباء الجدد، الأخبار العاجلة، أو مواعيد المواصلات. يمكنك تعطيل هذا الإذن في أي وقت من إعدادات الهاتف.</li>
              <li><strong>الاتصال الهاتفي المباشر:</strong> لتسهيل الاتصال السريع بالأطباء والمحلات وجهات الطوارئ مباشرة من داخل التطبيق دون الحاجة لنسخ الأرقام.</li>
            </ul>
          </div>

          {/* Section 3 */}
          <div className="space-y-2">
            <h2 className="text-base font-black text-slate-900">3. حماية البيانات (Data Security)</h2>
            <p>
              نحن نلتزم باستخدام أعلى معايير الأمان لحماية أي بيانات يتم تبادلها داخل التطبيق. نستخدم قاعدة بيانات سحابية آمنة ومشفرة بروتوكول نقل آمن (HTTPS) لضمان عدم تعرض البيانات للتدخل أو الاختراق.
            </p>
          </div>

          {/* Section 4 */}
          <div className="space-y-2">
            <h2 className="text-base font-black text-slate-905">4. خدمات الطرف الثالث وبرنامج الإعلانات</h2>
            <p>
              التطبيق لا يستخدم أي شبكات إعلانية تابعة لجهات خارجية تجمع معرفات الأجهزة أو معلومات التتبع الإعلاني، ولا نستخدم أدوات التتبع الخفية.
            </p>
          </div>

          {/* Section 5 */}
          <div className="space-y-2">
            <h2 className="text-base font-black text-slate-900">5. خصوصية الأطفال (Children's Privacy)</h2>
            <p>
              تطبيقنا مناسب لجميع الأعمار (بما في ذلك الأطفال تحت سن 13 عامًا) لأنه دليل خدمات عام لا يحتوي على أي محتوى غير مناسب، ولا يجمع أي معلومات شخصية منهم على الإطلاق.
            </p>
          </div>

          {/* Section 6 */}
          <div className="space-y-2">
            <h2 className="text-base font-black text-slate-900">6. التغييرات على سياسة الخصوصية</h2>
            <p>
              قد نقوم بتحديث سياسة الخصوصية هذه من وقت لآخر لمواكبة متطلبات متجر Google Play. ننصحك بمراجعة هذه الصفحة بشكل دوري لمعرفة أي تغييرات.
            </p>
          </div>

          {/* Section 7 - Contact */}
          <div className="border-t border-slate-100 pt-6 mt-8 space-y-3">
            <h2 className="text-base font-black text-slate-900 flex items-center gap-2 justify-end">
              <span>اتصل بنا بخصوص الخصوصية</span>
              <HelpCircle className="w-5 h-5 text-blue-600" />
            </h2>
            <p className="text-xs">
              إذا كانت لديك أي أسئلة أو استفسارات حول سياسة الخصوصية الخاصة بنا، فلا تتردد في الاتصال بنا:
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-end text-xs font-mono">
              <div className="bg-slate-50 border border-slate-100 px-4 py-2.5 rounded-2xl flex items-center gap-2 justify-center">
                <Mail className="w-4 h-4 text-slate-400" />
                <span>الدعم الفني والبرمجة: {developerName}</span>
              </div>
              <div className="bg-slate-50 border border-slate-100 px-4 py-2.5 rounded-2xl flex items-center gap-2 justify-center">
                <Globe className="w-4 h-4 text-slate-400" />
                <span>رابط الموقع: {window.location.origin}</span>
              </div>
            </div>
          </div>

          {/* Footer Info */}
          <div className="text-center text-[10px] text-slate-400 font-bold border-t border-slate-100 pt-6 mt-8">
            آخر تحديث للوثيقة: مايو 2026 م • تم إعداد هذه الصفحة خصيصاً لمتطلبات متجر جوجل بلاي.
          </div>

        </div>
      </div>
    </div>
  );
}
