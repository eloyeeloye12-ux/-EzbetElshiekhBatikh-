import { useState, useMemo, useEffect, useRef } from "react";
import { VillageData, Category, ServiceEntry } from "../types";
import * as LucideIcons from "lucide-react";
import {
  Search,
  Shield,
  Megaphone,
  Download,
  X,
  Stethoscope,
  Store,
  Bus,
  Home,
  Phone,
  ArrowRight,
  Heart,
  Hammer,
  Car,
  PlusSquare,
  MapPin,
  Users,
  MessageSquare,
  Send,
  Sparkles,
  Share2,
  Copy,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Fuse from "fuse.js";
import { addEntity } from "../services/firebaseService";
import AIChat from "./AIChat";

export const CATEGORY_STYLES: Record<string, { color: string; bgColor: string; dbCategory: string; group?: string }> = {
  "realestate-sell": { color: "text-emerald-500", bgColor: "bg-emerald-50", dbCategory: "realestate", group: "buy-sell" },
  "cars": { color: "text-blue-600", bgColor: "bg-blue-50", dbCategory: "cars", group: "buy-sell" },
  "motorcycles": { color: "text-red-500", bgColor: "bg-red-50/70", dbCategory: "cars", group: "buy-sell" },
  "mobile-phone": { color: "text-sky-500", bgColor: "bg-sky-50", dbCategory: "mobile", group: "buy-sell" },
  "realestate-rent": { color: "text-emerald-600", bgColor: "bg-emerald-50/70", dbCategory: "realestate", group: "buy-sell" },
  "home-app": { color: "text-teal-500", bgColor: "bg-teal-50", dbCategory: "home-app", group: "buy-sell" },
  "laptop-pc": { color: "text-indigo-600", bgColor: "bg-indigo-50", dbCategory: "mobile", group: "buy-sell" },
  "animals": { color: "text-green-500", bgColor: "bg-green-50", dbCategory: "supermarkets", group: "buy-sell" },
  "garden": { color: "text-emerald-600", bgColor: "bg-emerald-50", dbCategory: "home-app", group: "buy-sell" },
  "games": { color: "text-purple-500", bgColor: "bg-purple-50", dbCategory: "mobile", group: "buy-sell" },
  "sports": { color: "text-amber-500", bgColor: "bg-amber-50", dbCategory: "crafts", group: "buy-sell" },
  "clothes": { color: "text-pink-500", bgColor: "bg-pink-50", dbCategory: "clothes", group: "buy-sell" },
  "electronics": { color: "text-slate-600", bgColor: "bg-slate-50", dbCategory: "mobile", group: "buy-sell" },
  "jobs": { color: "text-blue-500", bgColor: "bg-blue-50", dbCategory: "crafts", group: "buy-sell" },
  "freelancers": { color: "text-cyan-600", bgColor: "bg-cyan-50", dbCategory: "crafts", group: "buy-sell" },

  "doctors": { color: "text-rose-500", bgColor: "bg-rose-50", dbCategory: "doctors", group: "directory" },
  "shops": { color: "text-blue-500", bgColor: "bg-blue-50", dbCategory: "supermarkets", group: "directory" },
  "transport": { color: "text-emerald-500", bgColor: "bg-emerald-50", dbCategory: "transport", group: "directory" },
  "computer-repair": { color: "text-indigo-500", bgColor: "bg-indigo-50", dbCategory: "mobile", group: "directory" },
  "clothes-dir": { color: "text-pink-500", bgColor: "bg-pink-50", dbCategory: "clothes", group: "directory" },
  "restaurants": { color: "text-orange-500", bgColor: "bg-orange-50", dbCategory: "restaurants", group: "directory" },
  "lost-found": { color: "text-amber-500", bgColor: "bg-amber-50", dbCategory: "supermarkets", group: "directory" },
  "nursery": { color: "text-pink-500", bgColor: "bg-pink-50", dbCategory: "supermarkets", group: "directory" },
  "teachers": { color: "text-indigo-600", bgColor: "bg-indigo-50", dbCategory: "doctors", group: "directory" },
  "quran": { color: "text-sky-500", bgColor: "bg-sky-50", dbCategory: "supermarkets", group: "directory" },
  "lawyers": { color: "text-amber-600", bgColor: "bg-amber-50", dbCategory: "crafts", group: "directory" },
  "fatwa": { color: "text-green-600", bgColor: "bg-green-50", dbCategory: "crafts", group: "directory" },
  "press": { color: "text-red-500", bgColor: "bg-red-50", dbCategory: "emergency", group: "directory" },
  "travel": { color: "text-teal-500", bgColor: "bg-teal-50", dbCategory: "transport", group: "directory" },
  "medication": { color: "text-purple-500", bgColor: "bg-purple-50", dbCategory: "doctors", group: "directory" },
  "officials": { color: "text-slate-700", bgColor: "bg-slate-100", dbCategory: "emergency", group: "directory" },
  "emergency": { color: "text-red-500", bgColor: "bg-red-50", dbCategory: "emergency", group: "directory" },
  "complaints": { color: "text-orange-500", bgColor: "bg-orange-50", dbCategory: "emergency", group: "directory" },
  "contact": { color: "text-emerald-500", bgColor: "bg-emerald-50", dbCategory: "supermarkets", group: "directory" }
};

export const mapCategoryToDbId = (id: string): string => {
  const custom = CATEGORY_STYLES[id];
  return custom ? custom.dbCategory : id;
};

interface VillageViewProps {
  data: VillageData;
  onAdminClick: () => void;
  triggerInstall: () => void;
  isStandalone: boolean;
  deferredPrompt: any;
  isIOS: boolean;
  isInAppBrowser: boolean;
}

const DynamicIcon = ({
  name,
  className,
}: {
  name: string;
  className?: string;
}) => {
  const IconComponent = (LucideIcons as any)[name] || LucideIcons.HelpCircle;
  return <IconComponent className={className} />;
};

const AnimatedTextBackground = ({ text }: { text: string }) => {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden select-none z-0">
      {/* Elegant slow-moving ambient glowing gradients inside the background */}
      <div className="absolute -left-1/4 -top-1/4 w-[150%] h-[150%] opacity-[0.05] bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-300 via-sky-100 to-transparent blur-3xl" />
      <div className="absolute -right-1/4 -bottom-1/4 w-[150%] h-[150%] opacity-[0.04] bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-200 via-blue-50 to-transparent blur-3xl animate-pulse duration-[8000ms]" />

      <div className="absolute -inset-20 flex flex-col justify-between h-[150%] rotate-[-12deg] py-8 scale-110 opacity-[0.09]">
        {Array.from({ length: 16 }).map((_, r) => (
          <div
            key={r}
            className="flex whitespace-nowrap gap-12 text-[15px] font-black tracking-widest text-blue-900"
            style={{
              animation:
                r % 2 === 0
                  ? "driftRight 24s linear infinite"
                  : "driftLeft 24s linear infinite",
              animationDelay: `${r * -1.5}s`,
            }}
          >
            {Array.from({ length: 12 }).map((_, c) => (
              <span
                key={c}
                className="mx-2 select-none flex items-center gap-3"
              >
                <span className="text-blue-950 font-black" translate="no">
                  {text}
                </span>
                <span className="text-blue-400/60 text-[10px] scale-90">✦</span>
              </span>
            ))}
          </div>
        ))}
      </div>
      <style>{`
        @keyframes driftRight {
          0% { transform: translateX(-33.333%); }
          100% { transform: translateX(0%); }
        }
        @keyframes driftLeft {
          0% { transform: translateX(0%); }
          100% { transform: translateX(-33.333%); }
        }
      `}</style>
    </div>
  );
};

export default function VillageView({
  data,
  onAdminClick,
  triggerInstall,
  isStandalone,
  deferredPrompt,
  isIOS,
  isInAppBrowser,
}: VillageViewProps) {
  const approvedServices = useMemo(() => {
    return data.services.filter((s) => s.approved !== false);
  }, [data.services]);

  const userAnnouncements = useMemo(() => {
    return approvedServices.filter((s) => s.approved === true || (s.addedBy && s.addedBy !== "الأدمن" && s.addedBy !== "الادارة"));
  }, [approvedServices]);

  const buyAndSellCategories = useMemo(() => {
    return data.categories.filter((cat) => {
      const style = CATEGORY_STYLES[cat.id];
      const grp = style?.group || cat.group;
      return grp === "buy-sell";
    });
  }, [data.categories]);

  const directoryCategories = useMemo(() => {
    return data.categories.filter((cat) => {
      const style = CATEGORY_STYLES[cat.id];
      const grp = style?.group || cat.group;
      return grp !== "buy-sell"; // Fallbacks to directory
    });
  }, [data.categories]);

  const buyAndSellServicesCount = useMemo(() => {
    return approvedServices.filter(s => buyAndSellCategories.some(c => c.id === s.categoryId || mapCategoryToDbId(c.id) === s.categoryId)).length;
  }, [approvedServices, buyAndSellCategories]);

  const directoryServicesCount = useMemo(() => {
    return approvedServices.filter(s => directoryCategories.some(c => c.id === s.categoryId || mapCategoryToDbId(c.id) === s.categoryId)).length;
  }, [approvedServices, directoryCategories]);

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedService, setSelectedService] = useState<ServiceEntry | null>(
    null,
  );
  const [showSuggestModal, setShowSuggestModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [sendingFeedback, setSendingFeedback] = useState(false);

  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const showStatus = (msg: string) => {
    setStatusMessage(msg);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const isUpdatingFromPopState = useRef(false);

  // Synchronize browser/app back button/history popstate
  useEffect(() => {
    // Correctly initialize history's base state
    if (!window.history.state) {
      window.history.replaceState(
        {
          category: null,
          serviceId: null,
          aiChat: false,
          searchTerm: "",
          suggestModal: false,
          shareModal: false,
        },
        "",
      );
    }

    const handlePopState = (event: PopStateEvent) => {
      const state = event.state;
      if (state) {
        isUpdatingFromPopState.current = true;

        setSelectedCategory(state.category);

        if (state.serviceId) {
          const service = approvedServices.find((s) => s.id === state.serviceId);
          setSelectedService(service || null);
        } else {
          setSelectedService(null);
        }

        setShowAIChat(!!state.aiChat);
        setSearchTerm(state.searchTerm || "");
        setShowSuggestModal(!!state.suggestModal);
        setShowShareModal(!!state.shareModal);

        setTimeout(() => {
          isUpdatingFromPopState.current = false;
        }, 30);
      }
    };

    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, [approvedServices]);

  // Push state to browser history when navigating inside React state
  useEffect(() => {
    if (isUpdatingFromPopState.current) return;

    const currentHistState = window.history.state;
    const nextState = {
      category: selectedCategory,
      serviceId: selectedService ? selectedService.id : null,
      aiChat: showAIChat,
      searchTerm: searchTerm,
      suggestModal: showSuggestModal,
      shareModal: showShareModal,
    };

    const categoryChanged =
      selectedCategory !== (currentHistState?.category ?? null);
    const serviceChanged =
      (selectedService ? selectedService.id : null) !==
      (currentHistState?.serviceId ?? null);
    const chatChanged = showAIChat !== (currentHistState?.aiChat ?? false);
    const searchChanged = searchTerm !== "" && !currentHistState?.searchTerm;
    const suggestModalChanged =
      showSuggestModal !== (currentHistState?.suggestModal ?? false);
    const shareModalChanged =
      showShareModal !== (currentHistState?.shareModal ?? false);

    const isNewNavigation =
      categoryChanged ||
      serviceChanged ||
      chatChanged ||
      searchChanged ||
      suggestModalChanged ||
      shareModalChanged;

    if (isNewNavigation) {
      window.history.pushState(nextState, "");
    } else {
      window.history.replaceState(nextState, "");
    }
  }, [
    selectedCategory,
    selectedService,
    showAIChat,
    searchTerm,
    showSuggestModal,
    showShareModal,
  ]);

  const navigateBack = () => {
    const currentState = window.history.state;
    const hasActiveScreen =
      currentState &&
      (currentState.category !== null ||
        currentState.serviceId !== null ||
        currentState.aiChat === true ||
        currentState.searchTerm !== "" ||
        currentState.suggestModal === true ||
        currentState.shareModal === true);

    if (hasActiveScreen) {
      window.history.back();
    } else {
      // Manual state rollback fallback
      if (selectedService) {
        setSelectedService(null);
      } else if (selectedCategory) {
        setSelectedCategory(null);
      } else if (showAIChat) {
        setShowAIChat(false);
      } else if (showSuggestModal) {
        setShowSuggestModal(false);
      } else if (showShareModal) {
        setShowShareModal(false);
      } else if (searchTerm) {
        setSearchTerm("");
      }
    }
  };
  const [suggestion, setSuggestion] = useState({
    personName: "",
    shopName: "",
    phone: "",
    category: "",
    details: "",
    address: "",
    productImgUrl: "",
  });

  const compressImage = (
    base64Str: string,
    maxWidth = 800,
    maxHeight = 800,
    quality = 0.7,
  ): Promise<string> => {
    return new Promise((resolve) => {
      const img = new window.Image();
      img.src = base64Str;
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL("image/jpeg", quality));
        } else {
          resolve(base64Str);
        }
      };
      img.onerror = () => {
        resolve(base64Str);
      };
    });
  };

  const handleSendSuggestion = async () => {
    if (!suggestion.shopName)
      return showStatus("يرجى كتابة اسم الإعلان أو الخدمة");
    if (!suggestion.phone) return showStatus("يرجى كتابة رقم الهاتف");
    if (!suggestion.category) return showStatus("يرجى اختيار القسم المناسب للإعلان");

    setSendingFeedback(true);
    const id = "user-ad-" + Date.now().toString(36);
    const success = await addEntity("services", id, {
      id,
      name: suggestion.shopName,
      phoneNumber: suggestion.phone,
      categoryId: suggestion.category,
      description: suggestion.details || "إعلان مقدم من عميل وينتظر الموافقة",
      address: suggestion.address || "عزبة الشيخ بطيخ",
      photoUrl: suggestion.productImgUrl || "",
      gallery: [],
      addedBy: suggestion.personName || "عميل",
      approved: false, // Moderated by admin
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setSendingFeedback(false);
    if (success) {
      showStatus("تم تقديم إعلانك بنجاح! سينتظر موافقة الإدارة ليظهر للجميع.");
      setSuggestion({
        personName: "",
        shopName: "",
        phone: "",
        category: "",
        details: "",
        address: "",
        productImgUrl: "",
      });
      setShowSuggestModal(false);
    } else {
      showStatus("حدث خطأ أثناء الإرسال، يرجى المحاولة لاحقاً");
    }
  };

  const handleShareApp = () => {
    setShowShareModal(true);
  };

  const fuse = useMemo(
    () =>
      new Fuse(approvedServices, {
        keys: ["name", "description", "address"],
        threshold: 0.3,
      }),
    [approvedServices],
  );

  const filteredServices = useMemo(() => {
    let results = approvedServices;
    if (searchTerm) {
      results = fuse.search(searchTerm).map((r) => r.item);
    }
    if (selectedCategory) {
      const dbCategory = mapCategoryToDbId(selectedCategory);
      results = results.filter(
        (s) =>
          s.categoryId === selectedCategory ||
          s.categoryId === dbCategory
      );
    }
    return results;
  }, [searchTerm, selectedCategory, approvedServices, fuse]);

  const showSplash = false;

  return (
    <div
      className="max-w-md mx-auto min-h-screen bg-slate-50 relative pb-24 font-sans overflow-x-hidden"
      dir="rtl"
    >
      {/* Modern High-End Gradient Header Accent exactly matching standard app layouts */}
      <div className="absolute top-0 inset-x-0 h-[290px] bg-gradient-to-tr from-[#1b438c] via-[#002d72] to-[#041a45] pointer-events-none z-0 rounded-b-[42px] overflow-hidden">
        {/* Sleek ambient glowing light flare */}
        <div className="absolute top-[-20%] left-[-20%] w-[140%] h-[120%] opacity-20 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-sky-400 via-transparent to-transparent blur-3xl" />
      </div>

      <div className="relative z-10">
        {/* Elegant Top Action Bar layout */}
        <div className="flex items-center justify-between px-6 pt-7 pb-3">
          <div className="flex items-center gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onAdminClick}
              className="w-10 h-10 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center border border-white/10 hover:bg-white/20 transition-all shadow-md text-white"
            >
              <LucideIcons.Menu className="w-4.5 h-4.5 font-bold" />
            </motion.button>

            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => {
                showStatus("صفحة المفضلة قيد التجهيز وسيتم إطلاقها قريباً!");
              }}
              className="w-10 h-10 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center border border-white/10 hover:bg-white/20 transition-all shadow-md text-white"
            >
              <LucideIcons.Heart className="w-4.5 h-4.5 text-red-500 fill-red-500" />
            </motion.button>

            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowShareModal(true)}
              className="w-10 h-10 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center border border-white/10 hover:bg-white/20 transition-all shadow-md text-white"
            >
              <LucideIcons.Share2 className="w-4.5 h-4.5 text-sky-300" />
            </motion.button>

            {!isStandalone && (deferredPrompt || (window as any).deferredPrompt) && (
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={triggerInstall}
                className="w-10 h-10 bg-white/15 backdrop-blur-md rounded-xl flex items-center justify-center border border-amber-400/2 transition-all shadow-md text-amber-400"
              >
                <LucideIcons.Download className="w-4.5 h-4.5 text-amber-400 animate-bounce" />
              </motion.button>
            )}
          </div>

          <div className="text-right flex flex-col">
            <h1
              translate="no"
              className="text-2xl font-black text-white tracking-wide leading-none"
            >
              {data.settings.appName || "دليل عزبة الشيخ بطيخ"}
            </h1>
            <span className="text-[10px] text-sky-200/90 font-bold mt-1.5 leading-tight">
              {data.settings.splashSubtitle || "كل اللي تحتاجه في عزبة الشيخ بطيخ.. أسرع وأسهل"}
            </span>
          </div>
        </div>

        {/* Dynamic & Scrolling News Ribbon Banner */}
        <div className="px-6 mt-3">
          <motion.div
            whileTap={{ scale: 0.98 }}
            onClick={() => {
              if (data.settings.apkDownloadUrl) {
                window.open(data.settings.apkDownloadUrl, "_blank");
              } else {
                showStatus("تابع صفحتنا الرسمية لمشاهدة كافة أخبار مركز دار السلام!");
              }
            }}
            className="bg-white/10 backdrop-blur-md rounded-2xl p-3 flex items-center justify-between border border-white/15 cursor-pointer hover:bg-white/15 transition-all text-white text-right shadow-sm"
          >
            <span className="text-[10px] md:text-[11px] font-black text-white/95 truncate flex-1 pl-2">
              {data.news.length > 0
                ? data.news[0].content
                : "إضغط هنا لمتابعة صفحة دليل دار السلام الرسمية"}
            </span>
            <div className="bg-blue-600 text-white px-3 py-1 rounded-full text-[10px] font-black shrink-0 shadow-sm">
              أهم الأخبار
            </div>
          </motion.div>
        </div>

        {/* Search Area overlapping the top container header */}
        <div className="px-6 mt-6 relative z-20">
          <div className="relative group max-w-sm mx-auto">
            <input
              type="text"
              placeholder="ابحث عن قسم أو خدمة"
              className="w-full bg-white border border-slate-200/80 py-4.5 pr-13 pl-6 rounded-[24px] outline-none text-xs font-black text-slate-800 placeholder:text-slate-400 transition-all focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 shadow-[0_12px_24px_rgba(15,23,42,0.06)] text-right"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute right-5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
          </div>
        </div>
      </div>

      <div className="relative z-10 px-5 space-y-7 bg-slate-50 pt-6 min-h-screen">
        {!searchTerm && !selectedCategory ? (
          <>
            {/* Local Weather & Prayer Times Widget */}
            <section className="bg-gradient-to-br from-[#1b438c]/10 to-[#002d72]/5 rounded-[32px] p-5 border border-blue-100/40 shadow-sm text-right relative overflow-hidden animate-in fade-in slide-in-from-bottom-3 duration-500">
              <div className="absolute top-0 left-0 w-24 h-24 bg-sky-200/10 blur-2xl rounded-full" />
              
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-xl">☀️</span>
                  <div className="text-left">
                    <div className="text-xs font-black text-slate-800">٣٤° مئوية</div>
                    <div className="text-[9px] font-bold text-slate-400">مشمس دافئ اليوم</div>
                  </div>
                </div>
                <div className="text-right">
                  <h3 className="text-xs font-black text-[#002d72] flex items-center gap-1.5 justify-end">
                    <span>مواقيت الصلاة اليوم بالعزبة</span>
                    <LucideIcons.Clock className="w-3.5 h-3.5 text-blue-600" />
                  </h3>
                  <p className="text-[9px] font-bold text-slate-450 mt-0.5">السبت، ١٦ ذو الحجة ١٤٤٧ هـ</p>
                </div>
              </div>

              {/* Horizontally scrolling list of prayer times */}
              <div className="grid grid-cols-5 gap-1.5 pt-1">
                {[
                  { name: "الفجر", time: "04:15 ص", active: false },
                  { name: "الظهر", time: "12:58 م", active: true },
                  { name: "العصر", time: "04:35 م", active: false },
                  { name: "المغرب", time: "07:05 م", active: false },
                  { name: "العشاء", time: "08:35 م", active: false }
                ].map((p, pIdx) => (
                  <div 
                    key={`prayer-${pIdx}`}
                    className={`p-2 rounded-2xl flex flex-col items-center justify-center border text-center transition-all ${
                      p.active 
                        ? "bg-gradient-to-b from-blue-600 to-[#002d72] border-blue-400/20 text-white shadow-lg shadow-blue-900/10 scale-102" 
                        : "bg-white border-slate-100/70 text-slate-800"
                    }`}
                  >
                    <span className={`text-[9px] font-black ${p.active ? "text-sky-200" : "text-slate-400"}`}>{p.name}</span>
                    <span className="text-[10px] font-bold mt-1 font-mono">{p.time}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Emergency Hotline fast dial slider */}
            <section className="animate-in fade-in slide-in-from-bottom-4 duration-600">
              <div className="flex items-center justify-between mb-3 px-1">
                <span className="text-[9px] text-red-500 bg-red-50 px-2.5 py-0.5 rounded-full font-black flex items-center gap-1">
                  <span>خدمة ٢٤ ساعة</span>
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping" />
                </span>
                <h2 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <span className="w-1.5 h-3.5 bg-red-500 rounded-full inline-block" />
                  أرقام الطوارئ والاتصال السريع بالعزبة
                </h2>
              </div>

              <div className="flex gap-2.5 overflow-x-auto pb-1 no-scrollbar scroll-smooth snap-x">
                {[
                  { title: "الإسعاف", number: "123", icon: "FlameKindling", color: "from-red-500 to-rose-600" },
                  { title: "الشرطة/النجدة", number: "122", icon: "ShieldAlert", color: "from-blue-600 to-sky-700" },
                  { title: "المطافئ", number: "180", icon: "Flame", color: "from-orange-500 to-amber-600" },
                  { title: "طوارئ الكهرباء", number: "121", icon: "Zap", color: "from-yellow-500 to-amber-500" },
                  { title: "طوارئ المياه", number: "125", icon: "Droplet", color: "from-sky-500 to-teal-500" },
                ].map((h, hIdx) => {
                  return (
                    <a
                      key={`hotline-${hIdx}`}
                      href={`tel:${h.number}`}
                      className="snap-center shrink-0 w-[110px] bg-white border border-slate-100 p-3 rounded-2xl shadow-sm hover:shadow-md transition-all flex flex-col items-center text-center relative group"
                    >
                      <div className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${h.color} text-white flex items-center justify-center mb-1.5 shadow-sm group-hover:scale-105 transition-transform`}>
                        <DynamicIcon name={h.icon} className="w-4 h-4" />
                      </div>
                      <span className="text-[10px] font-black text-slate-800">{h.title}</span>
                      <span className="text-[11px] font-mono font-bold text-red-500 mt-0.5">{h.number}</span>
                    </a>
                  );
                })}
              </div>
            </section>

            {/* Category Section Group 1: أقسام البيع والشراء */}
            <section className="animate-in fade-in slide-in-from-bottom-5 duration-700">
              <div className="flex items-center justify-between mb-3 px-1">
                <span className="text-[10px] bg-sky-100 text-[#002d72] px-3 py-1 rounded-full font-black uppercase tracking-wider">
                  {buyAndSellServicesCount} إعلان نشط
                </span>
                <h2 className="text-base font-black text-slate-950 flex items-center gap-1.5">
                  <span className="w-1.5 h-3.5 bg-blue-600 rounded-full inline-block" />
                  أقسام البيع والشراء
                </h2>
              </div>

              {/* Grid block styled to fit 4 columns exactly */}
              <div className="grid grid-cols-4 gap-2 pb-2">
                {buyAndSellCategories.map((cat, idx) => (
                  <motion.button
                    key={`buy-sell-${cat.id || idx}`}
                    whileHover={{ y: -3, scale: 1.02 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      setSelectedCategory(cat.id);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="bg-white p-2.5 rounded-[22px] border border-slate-100 shadow-[0_4px_12px_rgba(0,0,0,0.015)] flex flex-col items-center justify-center gap-1.5 group overflow-hidden relative min-h-[96px] transition-all"
                  >
                    <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${(() => {
                      const style = CATEGORY_STYLES[cat.id] || { color: "text-blue-600", bgColor: "bg-blue-50" };
                      return `${style.bgColor} ${style.color}`;
                    })()} transition-all group-hover:scale-108 shadow-sm`}>
                      <DynamicIcon name={cat.icon} className="w-5.25 h-5.25 font-bold" />
                    </div>

                    <span
                      translate="no"
                      className="text-[10px] md:text-[10.5px] font-black leading-tight tracking-tight text-slate-800 text-center line-clamp-2 max-h-[2.4em] select-none"
                    >
                      {cat.name}
                    </span>
                  </motion.button>
                ))}
              </div>
            </section>

            {/* Category Section Group 2: أقسام الدليل */}
            <section className="animate-in fade-in slide-in-from-bottom-5 duration-700">
              <div className="flex items-center justify-between mb-3 px-1">
                <span className="text-[10px] bg-slate-200 text-slate-600 px-3 py-1 rounded-full font-black uppercase tracking-wider">
                  {directoryServicesCount} رقم خدمة
                </span>
                <h2 className="text-base font-black text-slate-950 flex items-center gap-1.5">
                  <span className="w-1.5 h-3.5 bg-slate-700 rounded-full inline-block" />
                  أقسام الدليل
                </h2>
              </div>

              {/* Grid block styled to fit 4 columns exactly */}
              <div className="grid grid-cols-4 gap-2 pb-8">
                {directoryCategories.map((cat, idx) => (
                  <motion.button
                    key={`directory-${cat.id || idx}`}
                    whileHover={{ y: -3, scale: 1.02 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      setSelectedCategory(cat.id);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="bg-white p-2.5 rounded-[22px] border border-slate-100 shadow-[0_4px_12px_rgba(0,0,0,0.015)] flex flex-col items-center justify-center gap-1.5 group overflow-hidden relative min-h-[96px] transition-all"
                  >
                    <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${(() => {
                      const style = CATEGORY_STYLES[cat.id] || { color: "text-blue-600", bgColor: "bg-blue-50" };
                      return `${style.bgColor} ${style.color}`;
                    })()} transition-all group-hover:scale-108 shadow-sm`}>
                      <DynamicIcon name={cat.icon} className="w-5.25 h-5.25 font-bold" />
                    </div>

                    <span
                      translate="no"
                      className="text-[10px] md:text-[10.5px] font-black leading-tight tracking-tight text-slate-800 text-center line-clamp-2 max-h-[2.4em] select-none"
                    >
                      {cat.name}
                    </span>
                  </motion.button>
                ))}
              </div>
            </section>

            {/* Dedicated Classified Ads & Announcements Board */}
            <section className="animate-in fade-in slide-in-from-bottom-5 duration-750">
              <div className="flex items-center justify-between mb-4 px-1">
                <span className="text-[10px] bg-amber-100 text-amber-700 px-3 py-1 rounded-full font-black animate-pulse">
                  {userAnnouncements.length} إعلان نشط
                </span>
                <h2 className="text-base font-black text-slate-950 flex items-center gap-1.5">
                  <span className="w-1.5 h-3.5 bg-amber-500 rounded-full inline-block" />
                  ساحة العروض وإعلانات الأهالي
                </h2>
              </div>

              {userAnnouncements.length === 0 ? (
                <div className="bg-gradient-to-br from-amber-500/5 to-orange-500/5 border border-amber-200 p-6 rounded-[28px] text-center shadow-inner relative overflow-hidden mb-6">
                  <div className="absolute -top-10 -right-10 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl" />
                  <div className="w-12 h-12 bg-amber-100/80 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-3 border border-amber-200">
                    <LucideIcons.Megaphone className="w-6 h-6 animate-bounce" />
                  </div>
                  <h3 className="text-sm font-black text-slate-850 mb-1">أعلن عن خدمتك أو محلك هنا مجاناً!</h3>
                  <p className="text-[11px] font-bold text-slate-450 mb-4 max-w-[280px] mx-auto leading-relaxed">
                    كن أول من يضيف إعلانه التجاري الخاص بالعزبة ليراه الجميع فور اعتماده من الإدارة.
                  </p>
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setShowSuggestModal(true)}
                    className="px-5 py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-2xl text-xs font-black shadow-md cursor-pointer inline-flex items-center gap-2"
                  >
                    <LucideIcons.Plus className="w-4 h-4" />
                    اضغط هنا وأضف إعلانك
                  </motion.button>
                </div>
              ) : (
                <div className="flex gap-4 overflow-x-auto pb-6 pt-1 no-scrollbar scroll-smooth snap-x">
                  {userAnnouncements.map((ad, idx) => (
                    <div
                      key={`user-ad-card-${ad.id || idx}`}
                      onClick={() => setSelectedService(ad)}
                      className="snap-center shrink-0 w-[240px] bg-white border border-slate-100 rounded-[28px] p-4 shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative group cursor-pointer overflow-hidden text-right"
                    >
                      <div className="space-y-3">
                        {/* Ad Image / Placeholder preview */}
                        <div className="w-full h-24 rounded-2xl bg-slate-50 overflow-hidden relative border border-slate-50 flex items-center justify-center">
                          {ad.photoUrl || ad.image ? (
                            <img
                              src={ad.photoUrl || ad.image}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              alt={ad.name}
                            />
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-amber-500/5 to-orange-500/5 flex flex-col items-center justify-center text-amber-500 gap-1">
                              <LucideIcons.Megaphone className="w-7 h-7 text-amber-500 opacity-60" />
                              <span className="text-[8px] font-black uppercase text-amber-600/70">إعلان ترويجي</span>
                            </div>
                          )}
                          <span className="absolute top-2 right-2 px-2.5 py-0.5 bg-amber-500 text-white text-[8px] font-black rounded-lg shadow-md leading-none border border-amber-400">
                            {data.categories.find(c => c.id === ad.categoryId)?.name || "عرض خاص"}
                          </span>
                        </div>

                        {/* Ad Content info */}
                        <div className="text-right">
                          <h4 className="text-xs font-black text-slate-900 line-clamp-1 truncate">{ad.name}</h4>
                          <p className="text-[10px] text-slate-400 font-bold leading-normal line-clamp-2 mt-1 h-[2.8em] overflow-hidden">
                            {ad.description || "لا تتوفر تفاصيل إضافية حول هذا الإعلان."}
                          </p>
                        </div>
                      </div>

                      {/* Publisher and Call details footer */}
                      <div className="flex items-center justify-between pt-3 border-t border-slate-100/80 mt-2">
                        <div className="text-right min-w-0 flex-1">
                          <span className="text-[9px] text-slate-400 font-bold block leading-none">المعلن:</span>
                          <span className="text-[10px] font-black text-slate-700 truncate block mt-0.5">{ad.addedBy || "أحد الأهالي"}</span>
                        </div>
                        
                        <a
                          href={`tel:${ad.phoneNumber}`}
                          onClick={(e) => e.stopPropagation()}
                          className="w-10 h-10 bg-green-500 hover:bg-green-600 text-white rounded-xl flex items-center justify-center shadow-md shadow-green-100 hover:scale-105 transition-all cursor-pointer"
                        >
                          <LucideIcons.Phone className="w-4.5 h-4.5 animate-pulse" />
                        </a>
                      </div>
                    </div>
                  ))}
                  
                  {/* Option card to prompt the user to add an ad/announcement */}
                  <div
                    onClick={() => setShowSuggestModal(true)}
                    className="snap-center shrink-0 w-[140px] bg-gradient-to-br from-[#002d72]/5 to-[#1b438c]/10 rounded-[28px] p-4 text-center flex flex-col items-center justify-center border border-dashed border-blue-200 hover:border-solid hover:border-blue-300 transition-all cursor-pointer group"
                  >
                    <div className="w-11 h-11 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm border border-blue-50 group-hover:scale-110 transition-transform duration-300 mb-2">
                      <LucideIcons.Plus className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-black text-slate-800 leading-tight">أعلن هنا مجاناً!</span>
                    <span className="text-[8px] font-bold text-slate-400 mt-1 block">أضف عرضك الخاص للجميع</span>
                  </div>
                </div>
              )}
            </section>

            {/* Professional Developer Signature Section */}
            <div className="pb-20">
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 rounded-[28px] p-6 relative overflow-hidden shadow-lg border border-slate-850">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent pointer-events-none" />
                <div className="relative z-10 flex flex-col items-center text-center">
                  <div className="w-14 h-14 bg-white/5 rounded-full p-1 shadow-2xl relative mb-3">
                    <div className="w-full h-full rounded-full overflow-hidden border-2 border-white/15">
                      {data.settings.developerImageUrl ? (
                        <img
                          src={data.settings.developerImageUrl}
                          className="w-full h-full object-cover"
                          alt="Developer"
                        />
                      ) : (
                        <div className="w-full h-full bg-slate-800 flex items-center justify-center text-white font-black text-xs">
                          {data.settings.developerName
                            ? data.settings.developerName.charAt(0)
                            : "ع"}
                        </div>
                      )}
                    </div>
                    <div className="absolute -bottom-1 -right-1 bg-blue-600 p-1 rounded-xl border-2 border-slate-950 shadow-xl">
                      <LucideIcons.Cpu className="w-3 h-3 text-white" />
                    </div>
                  </div>
                  <h4 className="text-blue-400 font-bold text-[8px] uppercase tracking-[0.25em] mb-1">
                    طوّر بواسطة المبرمج
                  </h4>
                  <h3 className="text-white text-xs font-black tracking-tight mb-2">
                    {data.settings.developerName || "علوي عبدالرزاق"}
                  </h3>
                  <button
                    onClick={() => {
                      window.history.pushState({ p: "privacy" }, "");
                      window.location.search = "?p=privacy";
                    }}
                    className="text-[10px] font-bold text-slate-400 hover:text-blue-450 border border-slate-800 rounded-full px-4 py-1.5 transition-all flex items-center gap-1.5 bg-slate-900/40 hover:bg-slate-900/80 active:scale-95 mx-auto"
                  >
                    <Shield className="w-2.5 h-2.5 text-blue-500" />
                    <span>سياسة الخصوصية (Privacy Policy)</span>
                  </button>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="space-y-8 pb-32">
            <div className="flex items-center gap-4 mb-10 text-right">
              <button
                onClick={navigateBack}
                className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-lg text-blue-600 active:scale-90 transition-all border border-blue-50"
              >
                <ArrowRight className="w-7 h-7" />
              </button>
              <div className="flex-1">
                <h2 className="text-3xl font-black text-gray-900">
                  {searchTerm
                    ? "نتائج البحث"
                    : data.categories.find((c) => c.id === selectedCategory)
                        ?.name}
                </h2>
                <p className="text-xs font-black text-gray-400 tracking-widest uppercase pr-1">
                  ({filteredServices.length}) متاح الآن
                </p>
              </div>
            </div>

            <div className="space-y-6">
              {filteredServices.length > 0 ? (
                filteredServices.map((service, idx) => (
                  <motion.div
                    layout
                    key={`view-service-${service.id || idx}`}
                    onClick={() => setSelectedService(service)}
                    className="bg-white p-6 rounded-[40px] shadow-sm border border-gray-100 flex items-center gap-5 group hover:shadow-xl transition-all cursor-pointer relative overflow-hidden"
                  >
                    <div className="w-20 h-20 rounded-3xl bg-gray-50 overflow-hidden flex-shrink-0 border border-white shadow-inner">
                      {service.photoUrl || service.image ? (
                        <img
                          src={service.photoUrl || service.image}
                          className="w-full h-full object-cover transition-transform group-hover:scale-110"
                          alt={service.name}
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-200">
                          <Store className="w-10 h-10" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 text-right">
                      <h4 className="text-xl font-black text-gray-800 mb-2">
                        {service.name}
                      </h4>
                      <div className="flex items-center justify-end gap-2">
                        {service.address && (
                          <span className="text-[10px] font-bold text-gray-400 flex items-center gap-1">
                            {service.address}
                            <MapPin className="w-3 h-3" />
                          </span>
                        )}
                        <span className="text-[10px] px-3 py-1 bg-blue-50 text-blue-600 rounded-lg font-black uppercase tracking-tighter">
                          {
                            data.categories.find(
                              (c) => c.id === service.categoryId,
                            )?.name
                          }
                        </span>
                      </div>
                    </div>
                    <a
                      href={`tel:${service.phoneNumber}`}
                      onClick={(e) => e.stopPropagation()}
                      className="w-12 h-12 bg-green-500 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-green-100 group-hover:scale-110 transition-transform"
                    >
                      <Phone className="w-6 h-6" />
                    </a>
                  </motion.div>
                ))
              ) : (
                <div className="text-center py-20 bg-white rounded-[40px] border-2 border-dashed border-gray-100">
                  <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Search className="w-10 h-10 text-gray-200" />
                  </div>
                  <h3 className="text-xl font-black text-gray-400">
                    لا توجد نتائج بحث
                  </h3>
                </div>
              )}
            </div>
          </div>
        )}
      </div>



      <AnimatePresence>
        {showSuggestModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[400] flex items-center justify-center p-6 bg-blue-900/60 backdrop-blur-md"
            onClick={() => setShowSuggestModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 30 }}
              className="bg-white w-full max-w-sm rounded-[40px] p-8 shadow-2xl relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setShowSuggestModal(false)}
                className="absolute top-6 left-6 text-gray-300 hover:text-gray-500 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-orange-50 text-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-4 border border-orange-100">
                  <LucideIcons.Megaphone className="w-8 h-8 animate-bounce" />
                </div>
                <h3 className="text-2xl font-black text-slate-900">
                  أضف إعلانك في الدليل
                </h3>
                <p className="text-gray-400 font-bold text-xs mt-2">
                  أدخل بيانات إعلانك/خدمتك ليتم مراجعته ثم تفعيله فوراً
                </p>
              </div>

              <div className="space-y-4">
                <input
                  className="w-full px-6 py-3.5 rounded-2xl bg-gray-50 border-2 border-transparent font-bold outline-none focus:border-orange-500 focus:bg-white transition-all shadow-inner text-right text-xs"
                  placeholder="اسم الإعلان أو الخدمة (مثلاً: سوبر ماركت الأمانة)"
                  value={suggestion.shopName}
                  onChange={(e) =>
                    setSuggestion({ ...suggestion, shopName: e.target.value })
                  }
                />
                <input
                  className="w-full px-6 py-3.5 rounded-2xl bg-gray-50 border-2 border-transparent font-bold outline-none focus:border-orange-500 focus:bg-white transition-all shadow-inner text-right animate-fade-in text-xs"
                  placeholder="اسم الشخص المعلن"
                  value={suggestion.personName}
                  onChange={(e) =>
                    setSuggestion({ ...suggestion, personName: e.target.value })
                  }
                />
                <input
                  className="w-full px-6 py-3.5 rounded-2xl bg-gray-50 border-2 border-transparent font-bold outline-none focus:border-orange-500 focus:bg-white transition-all shadow-inner text-left font-mono text-xs"
                  placeholder="رقم الهاتف للتواصل"
                  value={suggestion.phone}
                  onChange={(e) =>
                    setSuggestion({ ...suggestion, phone: e.target.value })
                  }
                />
                <select
                  className="w-full px-6 py-3.5 rounded-2xl bg-gray-50 border-2 border-transparent font-bold outline-none focus:border-orange-500 focus:bg-white transition-all shadow-inner text-right text-xs appearance-none"
                  value={suggestion.category}
                  onChange={(e) =>
                    setSuggestion({ ...suggestion, category: e.target.value })
                  }
                >
                  <option value="">اختر القسم المناسب للإعلان *</option>
                  {data.categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
                <input
                  className="w-full px-6 py-3.5 rounded-2xl bg-gray-50 border-2 border-transparent font-bold outline-none focus:border-orange-500 focus:bg-white transition-all shadow-inner text-right text-xs"
                  placeholder="العنوان وموقع الخدمة (اختياري)"
                  value={suggestion.address}
                  onChange={(e) =>
                    setSuggestion({ ...suggestion, address: e.target.value })
                  }
                />

                {/* Image Attachment Option */}
                <div className="flex flex-col gap-2 mt-1">
                  {suggestion.productImgUrl ? (
                    <div className="relative rounded-2xl overflow-hidden border border-blue-200 bg-gray-50 h-32 flex items-center justify-center shadow-inner">
                      <img
                        src={suggestion.productImgUrl}
                        className="h-full w-full object-cover"
                        alt="Product preview"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setSuggestion((prev) => ({
                            ...prev,
                            productImgUrl: "",
                          }))
                        }
                        className="absolute top-2 right-2 p-2 bg-red-600 text-white rounded-xl shadow-lg border border-red-500 hover:bg-rose-750 transition-colors active:scale-95 flex items-center justify-center"
                      >
                        <LucideIcons.Trash2 className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  ) : (
                    <label className="w-full flex items-center justify-center gap-3 py-4 rounded-2xl bg-gray-100 hover:bg-blue-50 border-2 border-dashed border-blue-200 hover:border-blue-450 transition-all cursor-pointer shadow-inner active:scale-98">
                      <LucideIcons.Image className="w-5 h-5 text-blue-500 animate-pulse" />
                      <span className="text-xs font-black text-blue-600 font-sans">
                        أضف صورة لمنتجك (من الاستوديو)
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              compressImage(reader.result as string).then(
                                (compressed) => {
                                  setSuggestion((prev) => ({
                                    ...prev,
                                    productImgUrl: compressed,
                                  }));
                                  showStatus("تم رفع وتجهيز الصورة بنجاح");
                                },
                              );
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                  )}
                </div>
                <textarea
                  className="w-full px-6 py-4 rounded-2xl bg-gray-50 border-2 border-transparent font-bold outline-none focus:border-blue-500 focus:bg-white transition-all shadow-inner min-h-[100px] text-right"
                  placeholder="تفاصيل إضافية (اختياري)"
                  value={suggestion.details}
                  onChange={(e) =>
                    setSuggestion({ ...suggestion, details: e.target.value })
                  }
                />
                <button
                  onClick={handleSendSuggestion}
                  disabled={sendingFeedback}
                  className="w-full py-5 bg-blue-600 text-white rounded-3xl font-black shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
                >
                  {sendingFeedback ? "جاري الإرسال..." : "إرسال الطلب"}
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {statusMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 50, x: "-50%" }}
            className="fixed bottom-24 left-1/2 bg-gray-900/90 backdrop-blur-md text-white px-8 py-5 rounded-[24px] shadow-2xl z-[100] flex items-center gap-4 min-w-[200px] justify-center"
          >
            <span className="font-bold text-sm">{statusMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Buttons perfectly aligned at the bottom */}
      <div className="fixed bottom-6 inset-x-0 max-w-md mx-auto px-6 flex justify-between gap-4 items-center z-40 pointer-events-none">
        {/* Floating trigger for Smart AI Assistant Chatbot */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowAIChat(true)}
          style={{ pointerEvents: "auto" }}
          className="flex-1 py-3.5 bg-gradient-to-r from-[#1b438c] to-[#041a45] text-white rounded-full shadow-2xl flex items-center justify-center gap-2 border-[2.5px] border-white font-sans cursor-pointer"
        >
          <LucideIcons.Sparkles className="w-4.5 h-4.5 text-yellow-300 animate-pulse" />
          <span className="text-xs font-black tracking-wide">اسأل الذكاء</span>
        </motion.button>

        {/* Floating trigger for suggesting new services/ads */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowSuggestModal(true)}
          style={{ pointerEvents: "auto" }}
          className="flex-1 py-3.5 bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-full shadow-2xl flex items-center justify-center gap-2 border-[2.5px] border-white font-sans cursor-pointer"
        >
          <LucideIcons.Megaphone className="w-4.5 h-4.5 text-white" />
          <span className="text-xs font-black tracking-wide">أضف إعلانك</span>
        </motion.button>
      </div>

      <AnimatePresence>
        {selectedService && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] flex items-center justify-center p-6 bg-blue-900/40 backdrop-blur-md"
            onClick={navigateBack}
          >
            <motion.div
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white w-full max-w-sm rounded-[45px] overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative h-56">
                <img
                  src={
                    selectedService.photoUrl ||
                    selectedService.image ||
                    "https://images.unsplash.com/photo-1540340334550-612b3c3acb75?q=80&w=800"
                  }
                  className="w-full h-full object-cover"
                  alt={selectedService.name}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <button
                  onClick={navigateBack}
                  className="absolute top-6 right-6 w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center text-white"
                >
                  <X className="w-6 h-6" />
                </button>
                <div className="absolute bottom-6 right-8 text-white text-right">
                  <h3 className="text-3xl font-black">
                    {selectedService.name}
                  </h3>
                  <p className="text-sm font-bold opacity-80">
                    {
                      data.categories.find(
                        (c) => c.id === selectedService.categoryId,
                      )?.name
                    }
                  </p>
                </div>
              </div>
              <div className="p-10 space-y-8">
                <a
                  href={`tel:${selectedService.phoneNumber}`}
                  className="flex bg-green-500 text-white p-5 rounded-[28px] items-center justify-center gap-4 font-black shadow-xl shadow-green-100 active:scale-95 transition-all text-xl"
                >
                  <Phone className="w-7 h-7" />
                  {selectedService.phoneNumber}
                </a>
                <div className="space-y-4 text-right">
                  <p className="text-gray-500 font-bold leading-relaxed text-lg line-clamp-4">
                    {selectedService.description ||
                      "عزبة الشيخ بطيخ تتمنى لكم يوماً سعيداً. تواصل مع مزود الخدمة مباشرة عبر الرقم الموضح أعلاه."}
                  </p>
                  {selectedService.address && (
                    <div className="flex items-center justify-end gap-3 text-gray-400 font-bold bg-gray-50 p-4 rounded-2xl">
                      <span className="text-sm">{selectedService.address}</span>
                      <MapPin className="w-5 h-5 text-blue-500" />
                    </div>
                  )}
                </div>
                <button
                  onClick={navigateBack}
                  className="w-full text-center font-black text-gray-300 hover:text-gray-400 transition-colors py-2"
                >
                  إغلاق
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAIChat && (
          <AIChat
            isOpen={showAIChat}
            onClose={() => setShowAIChat(false)}
            villageData={data}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showShareModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[400] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md"
            onClick={navigateBack}
          >
            <motion.div
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 30 }}
              className="bg-white w-full max-w-sm rounded-[42px] p-6 shadow-2xl relative border border-slate-100 flex flex-col items-center text-center"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={navigateBack}
                className="absolute top-6 left-6 text-gray-300 hover:text-gray-500 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
              <div className="mb-4 px-4 py-1.5 bg-blue-50 rounded-full text-blue-600 text-xs font-black tracking-widest">
                تنزيل ومشاركة التطبيق
              </div>

              <div className="bg-slate-50 border border-slate-100 w-full rounded-[30px] p-6 flex flex-col items-center">
                <div className="w-16 h-16 rounded-full border border-white shadow-md overflow-hidden bg-white mb-3">
                  <img
                    src={
                      data.settings.logoUrl ||
                      "https://images.unsplash.com/photo-1500382017468-9049fed747ef"
                    }
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <h4 className="font-black text-slate-800 text-lg mb-1">
                  {data.settings.appName || "عزبة الشيخ بطيخ"}
                </h4>
                <p className="text-[11px] font-bold text-slate-400 mb-4 bg-slate-100/80 px-3 py-1 rounded-full">
                  امسح الكود بالهاتف للتنزيل الفوري
                </p>

                <div className="bg-white p-4 rounded-[24px] shadow-sm border border-slate-100/80 mb-4">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&color=0b2545&data=${encodeURIComponent("https://ais-pre-tdjrgwzjvudajc7sk47x6i-387878782937.europe-west2.run.app")}`}
                    alt="QR Code"
                    className="w-44 h-44 object-contain"
                  />
                </div>

                <p className="text-[10px] font-mono font-bold text-blue-600/70 select-all tracking-tight break-all">
                  https://ais-pre-tdjrgwzjvudajc7sk47x6i-387878782937.europe-west2.run.app
                </p>
              </div>

              <button
                onClick={() => {
                  navigator.clipboard.writeText(
                    "https://ais-pre-tdjrgwzjvudajc7sk47x6i-387878782937.europe-west2.run.app",
                  );
                  showStatus("تم نسخ رابط التطبيق بنجاح!");
                }}
                className="w-full mt-5 py-4 bg-blue-600 text-white rounded-[24px] font-black shadow-xl shadow-blue-100 flex items-center justify-center gap-2 active:scale-95 transition-all text-sm"
              >
                <Copy className="w-4 h-4" />
                نسخ رابط التطبيق
              </button>

              <div className="mt-5 text-right w-full bg-slate-50 border border-slate-100 p-4 rounded-2xl space-y-2.5">
                <h5 className="text-xs font-black text-slate-800 flex items-center gap-1.5 justify-end">
                  <span>طريقة التثبيت كـ تطبيق مستقل (PWA)</span>
                  <Download className="w-4 h-4 text-blue-600" />
                </h5>
                <div className="border-t border-slate-200/50 my-1" />
                <p className="text-[11px] font-bold text-slate-500 leading-relaxed">
                  <span className="text-blue-600">للأندرويد:</span> افتح الرابط
                  في متصفح Chrome، ثم اضغط على القائمة (٣ نقاط) واختر{" "}
                  <span className="text-slate-800">
                    "إضافة إلى الشاشة الرئيسية"
                  </span>
                  .
                </p>
                <p className="text-[11px] font-bold text-slate-500 leading-relaxed">
                  <span className="text-blue-600">للآيفون:</span> افتح الرابط في
                  متصفح Safari، ثم اضغط على زر المشاركة الأسفل واختر{" "}
                  <span className="text-slate-800">
                    "إضافة إلى الشاشة الرئيسية"
                  </span>
                  .
                </p>
              </div>

              <button
                onClick={navigateBack}
                className="w-full text-center font-black text-gray-400 hover:text-gray-500 transition-colors py-2 mt-3 text-sm"
              >
                إغلاق
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function NavButton({
  id,
  icon,
  label,
  active,
  onClick,
  highlight,
}: {
  id?: string;
  icon: any;
  label: string;
  active?: boolean;
  onClick?: () => void;
  highlight?: boolean;
}) {
  return (
    <button
      id={id}
      onClick={onClick}
      style={{ cursor: "pointer", pointerEvents: "auto" }}
      className={`flex flex-col items-center gap-1.5 p-3 min-w-[70px] transition-all relative ${active ? "scale-110" : "opacity-80 hover:opacity-100 text-white"}`}
    >
      <div
        className={`transition-all duration-500 ${active ? "text-blue-400 scale-125" : highlight ? "text-blue-300" : "text-white"}`}
      >
        {icon}
      </div>
      <span
        className={`text-[10px] font-black tracking-widest ${active ? "text-blue-400" : "text-white"}`}
      >
        {label}
      </span>
      {active && (
        <motion.div
          layoutId="active-nav"
          className="absolute -top-1 w-1 h-1 bg-blue-400 rounded-full shadow-[0_0_10px_#60a5fa]"
        />
      )}
    </button>
  );
}
