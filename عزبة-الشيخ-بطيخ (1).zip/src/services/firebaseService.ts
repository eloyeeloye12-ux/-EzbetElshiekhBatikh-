import { initializeApp } from 'firebase/app';
import { 
  initializeFirestore,
  getDocs,
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  getDoc,
  updateDoc,
  query,
  orderBy,
  getDocFromServer,
  enableIndexedDbPersistence,
  persistentLocalCache,
  persistentMultipleTabManager
} from 'firebase/firestore';
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged } from 'firebase/auth';
import { getMessaging, getToken, onMessage } from 'firebase/messaging';
import firebaseConfig from '../../firebase-applet-config.json';
import { VillageData, Category, ServiceEntry, News, AppSettings } from '../types';

const app = initializeApp(firebaseConfig);

// Initialize Firestore with long polling for better resilience in proxy/iframe environments
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  })
}, firebaseConfig.firestoreDatabaseId);

export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export const messaging = typeof window !== 'undefined' ? getMessaging(app) : null;

export const requestNotificationPermission = async () => {
  if (!messaging) return null;
  
  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      const token = await getToken(messaging, {
        vapidKey: 'BMD_lT9X_qYv4gV_yQ9_gV_yQ9_gV_yQ9_gV_yQ9_gV_yQ9_gV_yQ9_gV_yQ9_gV_yQ9_gV_yQ9_gV_yQ9_g' 
      });
      console.log('FCM Token:', token);
      
      if (token) {
        const tokenRef = doc(db, 'fcm_tokens', token);
        await setDoc(tokenRef, {
          token,
          userId: auth.currentUser?.uid || 'anonymous',
          updatedAt: new Date().toISOString()
        });
      }
      return token;
    }
  } catch (error) {
    console.error('Error getting notification permission:', error);
  }
  return null;
};

// Connection test
export async function testConnection() {
  try {
    const testDoc = doc(db, 'settings', 'global');
    const snapshot = await getDoc(testDoc);
    return snapshot.exists() || true;
  } catch (error) {
    console.warn("Firestore connectivity check warning:", error);
    return false;
  }
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const loginWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error("Login failed:", error);
    return null;
  }
};

export const logout = () => signOut(auth);

// New type for sync metadata
export interface SyncMetadata {
  isFromCache: boolean;
  hasPendingWrites: boolean;
}

// Subscribe to all data with metadata awareness
export const subscribeToVillageData = (
  onUpdate: (data: VillageData, metadata: SyncMetadata) => void,
  onError?: (err: any) => void
) => {
  const data: VillageData = {
    categories: [],
    services: [],
    news: [],
    settings: { appName: "عزبة الشيخ بطيخ", logoUrl: "/app_icon.png" }
  };

  let metadata: SyncMetadata = { isFromCache: true, hasPendingWrites: false };

  const handleErr = (err: any, path: string) => {
    console.error(`Subscription error at ${path}:`, err);
    if (onError) onError(err);
    else handleFirestoreError(err, OperationType.LIST, path);
  };

  const updateAll = (snapMetadata: any) => {
    metadata = {
      isFromCache: snapMetadata.fromCache,
      hasPendingWrites: snapMetadata.hasPendingWrites
    };
    onUpdate({ ...data }, metadata);
  };

  const unsubCategories = onSnapshot(query(collection(db, 'categories'), orderBy('order')), (snapshot) => {
    data.categories = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Category));
    updateAll(snapshot.metadata);
  }, (err) => handleErr(err, 'categories'));

  const unsubServices = onSnapshot(query(collection(db, 'services'), orderBy('createdAt', 'desc')), (snapshot) => {
    data.services = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as ServiceEntry));
    updateAll(snapshot.metadata);
  }, (err) => handleErr(err, 'services'));

  const unsubNews = onSnapshot(query(collection(db, 'news'), orderBy('createdAt', 'desc')), (snapshot) => {
    const rawNews = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as News));
    
    // Maintain all news items so they are not deleted automatically
    data.news = rawNews;

    updateAll(snapshot.metadata);
  }, (err) => handleErr(err, 'news'));

  const unsubComments = onSnapshot(query(collection(db, 'comments'), orderBy('createdAt', 'desc')), (snapshot) => {
    data.comments = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as any));
    updateAll(snapshot.metadata);
  }, (err) => {
    console.log("Comments subscription restricted or failed (expected for non-admins)");
  });

  const unsubSettings = onSnapshot(doc(db, 'settings', 'global'), (snapshot) => {
    if (snapshot.exists()) {
      data.settings = { ...(snapshot.data() as AppSettings), firebase_loaded: true };
      updateAll(snapshot.metadata);
    }
  }, (err) => handleErr(err, 'settings/global'));

  return () => {
    unsubCategories();
    unsubServices();
    unsubNews();
    unsubComments();
    unsubSettings();
  };
};

export const updateSettings = async (settings: AppSettings) => {
  try {
    await setDoc(doc(db, 'settings', 'global'), settings);
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'settings/global');
    return false;
  }
};

export const addEntity = async (col: string, id: string, payload: any) => {
  try {
    await setDoc(doc(db, col, id), payload);
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${col}/${id}`);
    return false;
  }
};

export const deleteEntity = async (col: string, id: string) => {
  try {
    await deleteDoc(doc(db, col, id));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${col}/${id}`);
    return false;
  }
};

export const updateEntity = async (col: string, id: string, payload: any) => {
  try {
    await setDoc(doc(db, col, id), payload, { merge: true });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${col}/${id}`);
    return false;
  }
};
