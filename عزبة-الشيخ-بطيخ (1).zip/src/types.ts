export interface Category {
  id: string;
  name: string;
  icon: string;
  image?: string;
  order: number;
  group?: string;
}

export interface ServiceEntry {
  id: string;
  name: string;
  phoneNumber: string;
  categoryId: string;
  description: string;
  address?: string;
  photoUrl?: string;
  gallery?: string[];
  addedBy?: string;
  approved?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface News {
  id: string;
  title: string;
  content: string;
  type: "urgent" | "normal" | "event";
  addedBy?: string;
  createdAt: string;
}

export interface AppSettings {
  appName: string;
  logoUrl: string;
  homeIconUrl?: string;
  developerName?: string;
  developerImageUrl?: string;
  adminPassword?: string;
  splashTitle?: string;
  splashSubtitle?: string;
  splashPhone?: string;
  splashIconUrl?: string;
  hideLogoOverlay?: boolean;
  apkDownloadUrl?: string;
  welcomeMessage?: string;
  firebase_loaded?: boolean;
}

export interface VillageComment {
  id: string;
  userName: string;
  content: string;
  createdAt: string;
  imageUrl?: string;
}

export interface VillageData {
  categories: Category[];
  services: ServiceEntry[];
  news: News[];
  settings: AppSettings;
  comments?: VillageComment[];
}
