export interface RawDefaultCategory {
  id: string;
  name: string;
  icon: string;
  group: "buy-sell" | "directory";
  order: number;
}

export const DEFAULT_CATEGORIES: RawDefaultCategory[] = [
  // Buy & Sell Categories
  { id: "realestate-sell", name: "عقارات للبيع", icon: "Home", group: "buy-sell", order: 1 },
  { id: "cars", name: "بيع وشراء السيارات", icon: "Car", group: "buy-sell", order: 2 },
  { id: "motorcycles", name: "موتسيكلات", icon: "Bike", group: "buy-sell", order: 3 },
  { id: "mobile-phone", name: "موبايل وتابلت", icon: "Smartphone", group: "buy-sell", order: 4 },
  { id: "realestate-rent", name: "عقارات للإيجار", icon: "Home", group: "buy-sell", order: 5 },
  { id: "home-app", name: "أجهزة منزلية", icon: "Refrigerator", group: "buy-sell", order: 6 },
  { id: "laptop-pc", name: "لابتوب وكمبيوتر", icon: "Laptop", group: "buy-sell", order: 7 },
  { id: "animals", name: "نباتات وحيوانات", icon: "PawPrint", group: "buy-sell", order: 8 },
  { id: "garden", name: "منزل وحديقة", icon: "Sofa", group: "buy-sell", order: 9 },
  { id: "games", name: "ألعاب وفيديو", icon: "Gamepad2", group: "buy-sell", order: 10 },
  { id: "sports", name: "معدات رياضية", icon: "Dumbbell", group: "buy-sell", order: 11 },
  { id: "clothes", name: "ملابس وأحذية", icon: "Shirt", group: "buy-sell", order: 12 },
  { id: "electronics", name: "إلكترونيات", icon: "Tv", group: "buy-sell", order: 13 },
  { id: "jobs", name: "الوظائف", icon: "Briefcase", group: "buy-sell", order: 14 },
  { id: "freelancers", name: "حرفيين ومهن حرة", icon: "Hammer", group: "buy-sell", order: 15 },

  // Directory Categories
  { id: "doctors", name: "أطباء وصيدليات", icon: "Stethoscope", group: "directory", order: 16 },
  { id: "shops", name: "محلات دار السلام", icon: "Store", group: "directory", order: 17 },
  { id: "transport", name: "سواقين ومواصلات", icon: "Bus", group: "directory", order: 18 },
  { id: "computer-repair", name: "كمبيوتر وصيانة الموبايل", icon: "Cpu", group: "directory", order: 19 },
  { id: "clothes-dir", name: "ملابس وأحذية (دليل)", icon: "Shirt", group: "directory", order: 20 },
  { id: "restaurants", name: "مطاعم", icon: "Utensils", group: "directory", order: 21 },
  { id: "lost-found", name: "مفقودات", icon: "SearchCode", group: "directory", order: 22 },
  { id: "nursery", name: "حضانات أطفال", icon: "Baby", group: "directory", order: 23 },
  { id: "teachers", name: "مدرسين", icon: "GraduationCap", group: "directory", order: 24 },
  { id: "quran", name: "مكاتب تحفيظ القرآن", icon: "BookOpen", group: "directory", order: 25 },
  { id: "lawyers", name: "محامين واستشارات", icon: "Scale", group: "directory", order: 26 },
  { id: "fatwa", name: "فتوى واستشارات", icon: "Building2", group: "directory", order: 27 },
  { id: "press", name: "صحافة وإعلام", icon: "Newspaper", group: "directory", order: 28 },
  { id: "travel", name: "مكاتب سفر وسياحة", icon: "Plane", group: "directory", order: 29 },
  { id: "medication", name: "فائض أدوية", icon: "Pills", group: "directory", order: 30 },
  { id: "officials", name: "مسؤلي مركز وقري دار السلام", icon: "Building2", group: "directory", order: 31 },
  { id: "emergency", name: "حالات الطوارئ", icon: "Activity", group: "directory", order: 32 },
  { id: "complaints", name: "شكاوي رئاسة الوزراء", icon: "AlertTriangle", group: "directory", order: 33 },
  { id: "contact", name: "تواصل معنا", icon: "MessageCircle", group: "directory", order: 34 }
];
